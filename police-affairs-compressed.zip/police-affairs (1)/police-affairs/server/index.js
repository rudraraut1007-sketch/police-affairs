const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const db = require('./db');

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

// -----------------------------------------------------------------------------
// ANALYTICS & STATS ENDPOINTS (Powers tactical gauges & graphs)
// -----------------------------------------------------------------------------
app.get('/api/stats', (req, res) => {
  try {
    const totalOfficers = db.prepare('SELECT COUNT(*) as count FROM officers').get().count;
    const activeOfficers = db.prepare("SELECT COUNT(*) as count FROM officers WHERE status = 'Active'").get().count;
    const totalCases = db.prepare('SELECT COUNT(*) as count FROM cases').get().count;
    const activeCases = db.prepare("SELECT COUNT(*) as count FROM cases WHERE status NOT LIKE 'Closed%'").get().count;
    const solvedCases = db.prepare("SELECT COUNT(*) as count FROM cases WHERE status LIKE 'Closed%'").get().count;
    const totalPersons = db.prepare('SELECT COUNT(*) as count FROM persons').get().count;
    const totalSuspects = db.prepare("SELECT COUNT(*) as count FROM persons WHERE role = 'Suspect'").get().count;
    const totalArrests = db.prepare('SELECT COUNT(*) as count FROM arrests').get().count;
    const inCustodyArrests = db.prepare("SELECT COUNT(*) as count FROM arrests WHERE booking_status = 'In Custody'").get().count;
    const totalEvidence = db.prepare('SELECT COUNT(*) as count FROM evidence').get().count;
    const totalComplaints = db.prepare('SELECT COUNT(*) as count FROM complaints').get().count;
    const pendingComplaints = db.prepare("SELECT COUNT(*) as count FROM complaints WHERE status = 'Under Investigation' OR status = 'Pending Review'").get().count;

    // Clearance rate
    const clearanceRate = totalCases > 0 ? Math.round((solvedCases / totalCases) * 100) : 0;
    // Vault capacity index (simulated capacity load)
    const vaultCapacityPercent = Math.min(100, Math.round((totalEvidence / 20) * 100));
    // Departmental integrity score (100 minus weighted active critical complaints)
    const integrityScore = Math.max(40, 100 - (pendingComplaints * 8));

    // Distribution by Crime Type
    const casesByType = db.prepare(`
      SELECT type, COUNT(*) as count 
      FROM cases 
      GROUP BY type 
      ORDER BY count DESC
    `).all();

    // Priority breakdown
    const casesByPriority = db.prepare(`
      SELECT priority, COUNT(*) as count 
      FROM cases 
      GROUP BY priority
    `).all();

    // Recent activity log (latest cases, arrests, complaints)
    const recentCases = db.prepare(`
      SELECT c.case_id, c.case_number, c.title, c.priority, c.status, c.incident_date, o.name as officer_name
      FROM cases c
      LEFT JOIN officers o ON c.assigned_officer_id = o.officer_id
      ORDER BY c.incident_date DESC
      LIMIT 5
    `).all();

    const recentArrests = db.prepare(`
      SELECT a.arrest_id, p.name as person_name, a.charges, a.arrest_date, a.booking_status, o.name as officer_name
      FROM arrests a
      JOIN persons p ON a.person_id = p.person_id
      JOIN officers o ON a.officer_id = o.officer_id
      ORDER BY a.arrest_date DESC
      LIMIT 5
    `).all();

    res.json({
      summary: {
        totalOfficers,
        activeOfficers,
        totalCases,
        activeCases,
        solvedCases,
        totalPersons,
        totalSuspects,
        totalArrests,
        inCustodyArrests,
        totalEvidence,
        totalComplaints,
        pendingComplaints,
        clearanceRate,
        vaultCapacityPercent,
        integrityScore
      },
      casesByType,
      casesByPriority,
      recentCases,
      recentArrests
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// -----------------------------------------------------------------------------
// 1. OFFICERS CRUD
// -----------------------------------------------------------------------------
app.get('/api/officers', (req, res) => {
  try {
    const { department, status, search } = req.query;
    let query = `
      SELECT o.*,
        (SELECT COUNT(*) FROM cases c WHERE c.assigned_officer_id = o.officer_id) AS assigned_cases_count,
        (SELECT COUNT(*) FROM arrests a WHERE a.officer_id = o.officer_id) AS arrests_made_count,
        (SELECT COUNT(*) FROM complaints comp WHERE comp.officer_id = o.officer_id) AS complaints_count
      FROM officers o
      WHERE 1=1
    `;
    const params = [];
    if (department) {
      query += ' AND o.department = ?';
      params.push(department);
    }
    if (status) {
      query += ' AND o.status = ?';
      params.push(status);
    }
    if (search) {
      query += ' AND (o.name LIKE ? OR o.badge_number LIKE ? OR o.rank LIKE ?)';
      params.push(`%${search}%`, `%${search}%`, `%${search}%`);
    }
    query += ' ORDER BY o.rank ASC, o.name ASC';

    const officers = db.prepare(query).all(...params);
    res.json(officers);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/officers/:id', (req, res) => {
  try {
    const officer = db.prepare('SELECT * FROM officers WHERE officer_id = ?').get(req.params.id);
    if (!officer) return res.status(404).json({ error: 'Officer not found' });

    const assignedCases = db.prepare('SELECT * FROM cases WHERE assigned_officer_id = ?').all(req.params.id);
    const arrestsMade = db.prepare(`
      SELECT a.*, p.name as person_name, c.case_number
      FROM arrests a
      JOIN persons p ON a.person_id = p.person_id
      JOIN cases c ON a.case_id = c.case_id
      WHERE a.officer_id = ?
    `).all(req.params.id);
    const complaints = db.prepare('SELECT * FROM complaints WHERE officer_id = ?').all(req.params.id);

    res.json({ ...officer, assignedCases, arrestsMade, complaints });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/officers', (req, res) => {
  try {
    const { badge_number, name, rank, department, contact, email, hire_date, status, shift } = req.body;
    const stmt = db.prepare(`
      INSERT INTO officers (badge_number, name, rank, department, contact, email, hire_date, status, shift)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    const info = stmt.run(badge_number, name, rank, department, contact, email, hire_date, status || 'Active', shift || 'Day');
    res.status(201).json({ officer_id: info.lastInsertRowid, message: 'Officer registered successfully' });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.put('/api/officers/:id', (req, res) => {
  try {
    const { badge_number, name, rank, department, contact, email, hire_date, status, shift } = req.body;
    const stmt = db.prepare(`
      UPDATE officers 
      SET badge_number = ?, name = ?, rank = ?, department = ?, contact = ?, email = ?, hire_date = ?, status = ?, shift = ?
      WHERE officer_id = ?
    `);
    stmt.run(badge_number, name, rank, department, contact, email, hire_date, status, shift, req.params.id);
    res.json({ message: 'Officer updated successfully' });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.delete('/api/officers/:id', (req, res) => {
  try {
    db.prepare('DELETE FROM officers WHERE officer_id = ?').run(req.params.id);
    res.json({ message: 'Officer record deleted' });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// -----------------------------------------------------------------------------
// 2. CASES CRUD
// -----------------------------------------------------------------------------
app.get('/api/cases', (req, res) => {
  try {
    const { status, priority, type, search } = req.query;
    let query = `
      SELECT c.*, o.name as assigned_officer_name, o.badge_number as assigned_officer_badge, o.rank as assigned_officer_rank,
        (SELECT COUNT(*) FROM persons p WHERE p.linked_case_id = c.case_id) AS persons_count,
        (SELECT COUNT(*) FROM evidence e WHERE e.case_id = c.case_id) AS evidence_count,
        (SELECT COUNT(*) FROM arrests a WHERE a.case_id = c.case_id) AS arrests_count
      FROM cases c
      LEFT JOIN officers o ON c.assigned_officer_id = o.officer_id
      WHERE 1=1
    `;
    const params = [];
    if (status) {
      query += ' AND c.status = ?';
      params.push(status);
    }
    if (priority) {
      query += ' AND c.priority = ?';
      params.push(priority);
    }
    if (type) {
      query += ' AND c.type = ?';
      params.push(type);
    }
    if (search) {
      query += ' AND (c.case_number LIKE ? OR c.title LIKE ? OR c.location LIKE ? OR c.description LIKE ?)';
      params.push(`%${search}%`, `%${search}%`, `%${search}%`, `%${search}%`);
    }
    query += ' ORDER BY c.incident_date DESC';

    const cases = db.prepare(query).all(...params);
    res.json(cases);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/cases/:id', (req, res) => {
  try {
    const caseData = db.prepare(`
      SELECT c.*, o.name as assigned_officer_name, o.badge_number as assigned_officer_badge, o.rank as assigned_officer_rank, o.department as assigned_officer_dept
      FROM cases c
      LEFT JOIN officers o ON c.assigned_officer_id = o.officer_id
      WHERE c.case_id = ?
    `).get(req.params.id);

    if (!caseData) return res.status(404).json({ error: 'Case not found' });

    const persons = db.prepare('SELECT * FROM persons WHERE linked_case_id = ?').all(req.params.id);
    const evidence = db.prepare('SELECT * FROM evidence WHERE case_id = ?').all(req.params.id);
    const arrests = db.prepare(`
      SELECT a.*, p.name as person_name, o.name as officer_name
      FROM arrests a
      JOIN persons p ON a.person_id = p.person_id
      JOIN officers o ON a.officer_id = o.officer_id
      WHERE a.case_id = ?
    `).all(req.params.id);

    res.json({ ...caseData, persons, evidence, arrests });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/cases', (req, res) => {
  try {
    const { case_number, title, incident_date, location, type, priority, status, description, assigned_officer_id } = req.body;
    const stmt = db.prepare(`
      INSERT INTO cases (case_number, title, incident_date, location, type, priority, status, description, assigned_officer_id)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    const info = stmt.run(case_number, title, incident_date, location, type, priority || 'Medium', status || 'Open', description, assigned_officer_id || null);
    res.status(201).json({ case_id: info.lastInsertRowid, message: 'Case created successfully' });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.put('/api/cases/:id', (req, res) => {
  try {
    const { case_number, title, incident_date, location, type, priority, status, description, assigned_officer_id } = req.body;
    const stmt = db.prepare(`
      UPDATE cases 
      SET case_number = ?, title = ?, incident_date = ?, location = ?, type = ?, priority = ?, status = ?, description = ?, assigned_officer_id = ?
      WHERE case_id = ?
    `);
    stmt.run(case_number, title, incident_date, location, type, priority, status, description, assigned_officer_id || null, req.params.id);
    res.json({ message: 'Case updated successfully' });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.delete('/api/cases/:id', (req, res) => {
  try {
    db.prepare('DELETE FROM cases WHERE case_id = ?').run(req.params.id);
    res.json({ message: 'Case deleted' });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// -----------------------------------------------------------------------------
// 3. PERSONS CRUD
// -----------------------------------------------------------------------------
app.get('/api/persons', (req, res) => {
  try {
    const { role, case_id, search } = req.query;
    let query = `
      SELECT p.*, c.case_number, c.title as case_title, c.priority as case_priority
      FROM persons p
      JOIN cases c ON p.linked_case_id = c.case_id
      WHERE 1=1
    `;
    const params = [];
    if (role) {
      query += ' AND p.role = ?';
      params.push(role);
    }
    if (case_id) {
      query += ' AND p.linked_case_id = ?';
      params.push(case_id);
    }
    if (search) {
      query += ' AND (p.name LIKE ? OR p.national_id LIKE ? OR p.contact LIKE ? OR p.notes LIKE ?)';
      params.push(`%${search}%`, `%${search}%`, `%${search}%`, `%${search}%`);
    }
    query += ' ORDER BY p.person_id DESC';

    const persons = db.prepare(query).all(...params);
    res.json(persons);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/persons', (req, res) => {
  try {
    const { name, role, national_id, contact, email, address, notes, linked_case_id } = req.body;
    const stmt = db.prepare(`
      INSERT INTO persons (name, role, national_id, contact, email, address, notes, linked_case_id)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `);
    const info = stmt.run(name, role, national_id, contact, email, address, notes, linked_case_id);
    res.status(201).json({ person_id: info.lastInsertRowid, message: 'Person linked to case successfully' });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.put('/api/persons/:id', (req, res) => {
  try {
    const { name, role, national_id, contact, email, address, notes, linked_case_id } = req.body;
    const stmt = db.prepare(`
      UPDATE persons 
      SET name = ?, role = ?, national_id = ?, contact = ?, email = ?, address = ?, notes = ?, linked_case_id = ?
      WHERE person_id = ?
    `);
    stmt.run(name, role, national_id, contact, email, address, notes, linked_case_id, req.params.id);
    res.json({ message: 'Person record updated' });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.delete('/api/persons/:id', (req, res) => {
  try {
    db.prepare('DELETE FROM persons WHERE person_id = ?').run(req.params.id);
    res.json({ message: 'Person deleted' });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// -----------------------------------------------------------------------------
// 4. ARRESTS CRUD
// -----------------------------------------------------------------------------
app.get('/api/arrests', (req, res) => {
  try {
    const { booking_status, officer_id, search } = req.query;
    let query = `
      SELECT a.*, p.name as person_name, p.national_id, c.case_number, c.title as case_title, o.name as officer_name, o.badge_number as officer_badge
      FROM arrests a
      JOIN persons p ON a.person_id = p.person_id
      JOIN cases c ON a.case_id = c.case_id
      JOIN officers o ON a.officer_id = o.officer_id
      WHERE 1=1
    `;
    const params = [];
    if (booking_status) {
      query += ' AND a.booking_status = ?';
      params.push(booking_status);
    }
    if (officer_id) {
      query += ' AND a.officer_id = ?';
      params.push(officer_id);
    }
    if (search) {
      query += ' AND (p.name LIKE ? OR a.charges LIKE ? OR c.case_number LIKE ? OR a.facility_location LIKE ?)';
      params.push(`%${search}%`, `%${search}%`, `%${search}%`, `%${search}%`);
    }
    query += ' ORDER BY a.arrest_date DESC';

    const arrests = db.prepare(query).all(...params);
    res.json(arrests);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/arrests', (req, res) => {
  try {
    const { person_id, case_id, officer_id, charges, arrest_date, booking_status, bail_amount, facility_location } = req.body;
    const stmt = db.prepare(`
      INSERT INTO arrests (person_id, case_id, officer_id, charges, arrest_date, booking_status, bail_amount, facility_location)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `);
    const info = stmt.run(person_id, case_id, officer_id, charges, arrest_date, booking_status || 'In Custody', bail_amount || 0.00, facility_location || 'Central Processing Facility');
    res.status(201).json({ arrest_id: info.lastInsertRowid, message: 'Arrest booked successfully' });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.put('/api/arrests/:id', (req, res) => {
  try {
    const { person_id, case_id, officer_id, charges, arrest_date, booking_status, bail_amount, facility_location } = req.body;
    const stmt = db.prepare(`
      UPDATE arrests 
      SET person_id = ?, case_id = ?, officer_id = ?, charges = ?, arrest_date = ?, booking_status = ?, bail_amount = ?, facility_location = ?
      WHERE arrest_id = ?
    `);
    stmt.run(person_id, case_id, officer_id, charges, arrest_date, booking_status, bail_amount, facility_location, req.params.id);
    res.json({ message: 'Arrest record updated' });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.delete('/api/arrests/:id', (req, res) => {
  try {
    db.prepare('DELETE FROM arrests WHERE arrest_id = ?').run(req.params.id);
    res.json({ message: 'Arrest record removed' });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// -----------------------------------------------------------------------------
// 5. EVIDENCE CRUD
// -----------------------------------------------------------------------------
app.get('/api/evidence', (req, res) => {
  try {
    const { evidence_type, status, search } = req.query;
    let query = `
      SELECT e.*, c.case_number, c.title as case_title
      FROM evidence e
      JOIN cases c ON e.case_id = c.case_id
      WHERE 1=1
    `;
    const params = [];
    if (evidence_type) {
      query += ' AND e.evidence_type = ?';
      params.push(evidence_type);
    }
    if (status) {
      query += ' AND e.status = ?';
      params.push(status);
    }
    if (search) {
      query += ' AND (e.item_name LIKE ? OR e.description LIKE ? OR e.storage_location LIKE ? OR c.case_number LIKE ?)';
      params.push(`%${search}%`, `%${search}%`, `%${search}%`, `%${search}%`);
    }
    query += ' ORDER BY e.collected_date DESC';

    const evidence = db.prepare(query).all(...params);
    res.json(evidence);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/evidence', (req, res) => {
  try {
    const { case_id, item_name, description, evidence_type, storage_location, collected_date, chain_of_custody, status } = req.body;
    const stmt = db.prepare(`
      INSERT INTO evidence (case_id, item_name, description, evidence_type, storage_location, collected_date, chain_of_custody, status)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `);
    const info = stmt.run(case_id, item_name, description, evidence_type || 'Physical', storage_location, collected_date, chain_of_custody, status || 'In Vault');
    res.status(201).json({ evidence_id: info.lastInsertRowid, message: 'Evidence logged into vault successfully' });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.put('/api/evidence/:id', (req, res) => {
  try {
    const { case_id, item_name, description, evidence_type, storage_location, collected_date, chain_of_custody, status } = req.body;
    const stmt = db.prepare(`
      UPDATE evidence 
      SET case_id = ?, item_name = ?, description = ?, evidence_type = ?, storage_location = ?, collected_date = ?, chain_of_custody = ?, status = ?
      WHERE evidence_id = ?
    `);
    stmt.run(case_id, item_name, description, evidence_type, storage_location, collected_date, chain_of_custody, status, req.params.id);
    res.json({ message: 'Evidence item updated' });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.delete('/api/evidence/:id', (req, res) => {
  try {
    db.prepare('DELETE FROM evidence WHERE evidence_id = ?').run(req.params.id);
    res.json({ message: 'Evidence item deleted' });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// -----------------------------------------------------------------------------
// 6. COMPLAINTS (INTERNAL AFFAIRS) CRUD
// -----------------------------------------------------------------------------
app.get('/api/complaints', (req, res) => {
  try {
    const { status, severity, allegation_type, search } = req.query;
    let query = `
      SELECT comp.*, o.name as officer_name, o.badge_number as officer_badge, o.rank as officer_rank, o.department as officer_dept
      FROM complaints comp
      JOIN officers o ON comp.officer_id = o.officer_id
      WHERE 1=1
    `;
    const params = [];
    if (status) {
      query += ' AND comp.status = ?';
      params.push(status);
    }
    if (severity) {
      query += ' AND comp.severity = ?';
      params.push(severity);
    }
    if (allegation_type) {
      query += ' AND comp.allegation_type = ?';
      params.push(allegation_type);
    }
    if (search) {
      query += ' AND (comp.complaint_number LIKE ? OR comp.complainant_name LIKE ? OR comp.description LIKE ? OR o.name LIKE ?)';
      params.push(`%${search}%`, `%${search}%`, `%${search}%`, `%${search}%`);
    }
    query += ' ORDER BY comp.filed_date DESC';

    const complaints = db.prepare(query).all(...params);
    res.json(complaints);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/complaints', (req, res) => {
  try {
    const { complaint_number, officer_id, complainant_name, complainant_contact, incident_date, filed_date, allegation_type, severity, description, status, investigator_notes, disciplinary_action } = req.body;
    const stmt = db.prepare(`
      INSERT INTO complaints (complaint_number, officer_id, complainant_name, complainant_contact, incident_date, filed_date, allegation_type, severity, description, status, investigator_notes, disciplinary_action)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    const info = stmt.run(complaint_number, officer_id, complainant_name, complainant_contact, incident_date, filed_date, allegation_type, severity || 'Medium', description, status || 'Under Investigation', investigator_notes, disciplinary_action);
    res.status(201).json({ complaint_id: info.lastInsertRowid, message: 'Internal Affairs Complaint lodged successfully' });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.put('/api/complaints/:id', (req, res) => {
  try {
    const { complaint_number, officer_id, complainant_name, complainant_contact, incident_date, filed_date, allegation_type, severity, status, description, investigator_notes, disciplinary_action } = req.body;
    const stmt = db.prepare(`
      UPDATE complaints 
      SET complaint_number = ?, officer_id = ?, complainant_name = ?, complainant_contact = ?, incident_date = ?, filed_date = ?, allegation_type = ?, severity = ?, status = ?, description = ?, investigator_notes = ?, disciplinary_action = ?
      WHERE complaint_id = ?
    `);
    stmt.run(complaint_number, officer_id, complainant_name, complainant_contact, incident_date, filed_date, allegation_type, severity, status, description, investigator_notes, disciplinary_action, req.params.id);
    res.json({ message: 'Complaint updated' });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.delete('/api/complaints/:id', (req, res) => {
  try {
    db.prepare('DELETE FROM complaints WHERE complaint_id = ?').run(req.params.id);
    res.json({ message: 'Complaint record removed' });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// -----------------------------------------------------------------------------
// 7. INTERACTIVE SQL QUERY RUNNER / PLAYGROUND (Academic & Power User)
// -----------------------------------------------------------------------------
app.post('/api/query', (req, res) => {
  try {
    const { sql } = req.body;
    if (!sql || typeof sql !== 'string') {
      return res.status(400).json({ error: 'SQL query string is required' });
    }

    const trimmed = sql.trim();
    const isSelect = /^(SELECT|PRAGMA|EXPLAIN|WITH)\b/i.test(trimmed);

    const startTime = process.hrtime();
    if (isSelect) {
      const rows = db.prepare(trimmed).all();
      const diff = process.hrtime(startTime);
      const executionTimeMs = (diff[0] * 1000 + diff[1] / 1e6).toFixed(2);
      
      const columns = rows.length > 0 ? Object.keys(rows[0]) : [];
      return res.json({
        success: true,
        type: 'SELECT',
        rowCount: rows.length,
        columns,
        rows,
        executionTimeMs
      });
    } else {
      const result = db.prepare(trimmed).run();
      const diff = process.hrtime(startTime);
      const executionTimeMs = (diff[0] * 1000 + diff[1] / 1e6).toFixed(2);
      
      return res.json({
        success: true,
        type: 'MUTATION',
        changes: result.changes,
        lastInsertRowid: result.lastInsertRowid,
        executionTimeMs
      });
    }
  } catch (err) {
    res.status(400).json({ success: false, error: err.message });
  }
});

// -----------------------------------------------------------------------------
// 8. MYSQL FULL DUMP EXPORT (Download ready-to-run .sql file)
// -----------------------------------------------------------------------------
app.get('/api/export-mysql', (req, res) => {
  try {
    const schemaFile = path.join(__dirname, '../database/schema_mysql.sql');
    const seedFile = path.join(__dirname, '../database/seed_mysql.sql');
    const queriesFile = path.join(__dirname, '../database/queries.sql');

    let schemaContent = fs.existsSync(schemaFile) ? fs.readFileSync(schemaFile, 'utf8') : '';
    let seedContent = fs.existsSync(seedFile) ? fs.readFileSync(seedFile, 'utf8') : '';
    let queriesContent = fs.existsSync(queriesFile) ? fs.readFileSync(queriesFile, 'utf8') : '';

    const fullDump = `${schemaContent}\n\n${seedContent}\n\n${queriesContent}`;

    res.setHeader('Content-Type', 'application/sql');
    res.setHeader('Content-Disposition', 'attachment; filename="police_affairs_mysql_dump.sql"');
    res.send(fullDump);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.listen(PORT, () => {
  console.log(`[Police Affairs Backend] API running on http://localhost:${PORT}`);
});
