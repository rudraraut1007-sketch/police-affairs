const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');

const dbPath = path.join(__dirname, 'police_affairs.db');
const db = new Database(dbPath);

// Enable foreign keys and WAL mode for high concurrency
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

function initDatabase() {
  const schema = `
    CREATE TABLE IF NOT EXISTS officers (
      officer_id INTEGER PRIMARY KEY AUTOINCREMENT,
      badge_number TEXT NOT NULL UNIQUE,
      name TEXT NOT NULL,
      rank TEXT NOT NULL,
      department TEXT NOT NULL,
      contact TEXT NOT NULL,
      email TEXT NOT NULL UNIQUE,
      hire_date TEXT NOT NULL,
      status TEXT DEFAULT 'Active' CHECK(status IN ('Active', 'On Leave', 'Suspended', 'Retired', 'Under Investigation')),
      shift TEXT DEFAULT 'Day' CHECK(shift IN ('Day', 'Evening', 'Night', 'Rotating')),
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS cases (
      case_id INTEGER PRIMARY KEY AUTOINCREMENT,
      case_number TEXT NOT NULL UNIQUE,
      title TEXT NOT NULL,
      incident_date DATETIME NOT NULL,
      reported_date DATETIME DEFAULT CURRENT_TIMESTAMP,
      location TEXT NOT NULL,
      type TEXT NOT NULL,
      priority TEXT DEFAULT 'Medium' CHECK(priority IN ('Low', 'Medium', 'High', 'Critical')),
      status TEXT DEFAULT 'Open' CHECK(status IN ('Open', 'Under Investigation', 'Pending Review', 'Closed - Solved', 'Closed - Unsolved')),
      description TEXT,
      assigned_officer_id INTEGER,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (assigned_officer_id) REFERENCES officers (officer_id) ON DELETE SET NULL ON UPDATE CASCADE
    );

    CREATE TABLE IF NOT EXISTS persons (
      person_id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      role TEXT NOT NULL CHECK(role IN ('Victim', 'Witness', 'Suspect', 'Person of Interest', 'Informant')),
      national_id TEXT,
      contact TEXT,
      email TEXT,
      address TEXT,
      notes TEXT,
      linked_case_id INTEGER NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (linked_case_id) REFERENCES cases (case_id) ON DELETE CASCADE ON UPDATE CASCADE
    );

    CREATE TABLE IF NOT EXISTS arrests (
      arrest_id INTEGER PRIMARY KEY AUTOINCREMENT,
      person_id INTEGER NOT NULL,
      case_id INTEGER NOT NULL,
      officer_id INTEGER NOT NULL,
      charges TEXT NOT NULL,
      arrest_date DATETIME NOT NULL,
      booking_status TEXT DEFAULT 'In Custody' CHECK(booking_status IN ('In Custody', 'Released on Bail', 'Transferred to Prison', 'Charges Dropped', 'Awaiting Trial')),
      bail_amount REAL DEFAULT 0.00,
      facility_location TEXT DEFAULT 'Central Processing Facility',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (person_id) REFERENCES persons (person_id) ON DELETE RESTRICT ON UPDATE CASCADE,
      FOREIGN KEY (case_id) REFERENCES cases (case_id) ON DELETE CASCADE ON UPDATE CASCADE,
      FOREIGN KEY (officer_id) REFERENCES officers (officer_id) ON DELETE RESTRICT ON UPDATE CASCADE
    );

    CREATE TABLE IF NOT EXISTS evidence (
      evidence_id INTEGER PRIMARY KEY AUTOINCREMENT,
      case_id INTEGER NOT NULL,
      item_name TEXT NOT NULL,
      description TEXT NOT NULL,
      evidence_type TEXT DEFAULT 'Physical' CHECK(evidence_type IN ('Physical', 'Digital', 'Biological/DNA', 'Ballistics', 'Documentary', 'Narcotics', 'Other')),
      storage_location TEXT NOT NULL,
      collected_date DATETIME NOT NULL,
      chain_of_custody TEXT,
      status TEXT DEFAULT 'In Vault' CHECK(status IN ('In Vault', 'In Forensics Lab', 'Presented in Court', 'Disposed / Returned')),
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (case_id) REFERENCES cases (case_id) ON DELETE CASCADE ON UPDATE CASCADE
    );

    CREATE TABLE IF NOT EXISTS complaints (
      complaint_id INTEGER PRIMARY KEY AUTOINCREMENT,
      complaint_number TEXT NOT NULL UNIQUE,
      officer_id INTEGER NOT NULL,
      complainant_name TEXT NOT NULL,
      complainant_contact TEXT,
      incident_date TEXT NOT NULL,
      filed_date TEXT NOT NULL,
      allegation_type TEXT NOT NULL CHECK(allegation_type IN ('Excessive Force', 'Misconduct', 'Corruption / Bribery', 'Dereliction of Duty', 'Harassment', 'Procedural Violation', 'Unlawful Search')),
      severity TEXT DEFAULT 'Medium' CHECK(severity IN ('Low', 'Medium', 'High', 'Critical')),
      description TEXT NOT NULL,
      status TEXT DEFAULT 'Under Investigation' CHECK(status IN ('Pending Review', 'Under Investigation', 'Sustained (Guilty)', 'Exonerated (Cleared)', 'Unfounded / Dismissed')),
      investigator_notes TEXT,
      disciplinary_action TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (officer_id) REFERENCES officers (officer_id) ON DELETE CASCADE ON UPDATE CASCADE
    );
  `;

  db.exec(schema);

  // Check if we need to seed
  const count = db.prepare('SELECT COUNT(*) as count FROM officers').get();
  if (count.count === 0) {
    seedDatabase();
  }
}

function seedDatabase() {
  const insertOfficer = db.prepare(`
    INSERT INTO officers (officer_id, badge_number, name, rank, department, contact, email, hire_date, status, shift)
    VALUES (@officer_id, @badge_number, @name, @rank, @department, @contact, @email, @hire_date, @status, @shift)
  `);

  const officers = [
    { officer_id: 1, badge_number: 'BADGE-104', name: 'Captain James Vance', rank: 'Captain', department: 'Internal Affairs Division', contact: '+1-555-0199', email: 'j.vance@metropolice.gov', hire_date: '2012-04-15', status: 'Active', shift: 'Day' },
    { officer_id: 2, badge_number: 'BADGE-219', name: 'Detective Marcus Brody', rank: 'Detective First Grade', department: 'Homicide Division', contact: '+1-555-0211', email: 'm.brody@metropolice.gov', hire_date: '2015-08-20', status: 'Active', shift: 'Day' },
    { officer_id: 3, badge_number: 'BADGE-342', name: 'Detective Elena Rostova', rank: 'Senior Detective', department: 'Cyber & Financial Crimes', contact: '+1-555-0344', email: 'e.rostova@metropolice.gov', hire_date: '2018-01-10', status: 'Active', shift: 'Evening' },
    { officer_id: 4, badge_number: 'BADGE-405', name: 'Sergeant David Cole', rank: 'Sergeant', department: 'Major Narcotics Unit', contact: '+1-555-0455', email: 'd.cole@metropolice.gov', hire_date: '2016-11-05', status: 'Under Investigation', shift: 'Night' },
    { officer_id: 5, badge_number: 'BADGE-512', name: 'Officer Sarah Jenkins', rank: 'Patrol Officer', department: 'Patrol & Field Ops', contact: '+1-555-0588', email: 's.jenkins@metropolice.gov', hire_date: '2021-03-22', status: 'Active', shift: 'Rotating' },
    { officer_id: 6, badge_number: 'BADGE-630', name: 'Lieutenant Frank Sterling', rank: 'Lieutenant', department: 'Special Investigations', contact: '+1-555-0677', email: 'f.sterling@metropolice.gov', hire_date: '2010-09-01', status: 'Active', shift: 'Day' },
    { officer_id: 7, badge_number: 'BADGE-718', name: 'Detective Alex Mercer', rank: 'Detective', department: 'Robbery & Burglary', contact: '+1-555-0722', email: 'a.mercer@metropolice.gov', hire_date: '2019-06-14', status: 'Active', shift: 'Day' },
    { officer_id: 8, badge_number: 'BADGE-809', name: 'Officer Malik Reed', rank: 'Patrol Officer', department: 'Patrol & Field Ops', contact: '+1-555-0899', email: 'm.reed@metropolice.gov', hire_date: '2022-02-18', status: 'Active', shift: 'Night' },
    { officer_id: 9, badge_number: 'BADGE-921', name: 'Detective Chloe Bennett', rank: 'Detective', department: 'Forensic & Evidence Unit', contact: '+1-555-0944', email: 'c.bennett@metropolice.gov', hire_date: '2017-05-30', status: 'Active', shift: 'Day' },
    { officer_id: 10, badge_number: 'BADGE-990', name: 'Officer Tyler Vance', rank: 'Patrol Officer', department: 'Traffic Enforcement', contact: '+1-555-0991', email: 't.vance@metropolice.gov', hire_date: '2023-01-12', status: 'Active', shift: 'Rotating' }
  ];

  const insertCases = db.prepare(`
    INSERT INTO cases (case_id, case_number, title, incident_date, reported_date, location, type, priority, status, description, assigned_officer_id)
    VALUES (@case_id, @case_number, @title, @incident_date, @reported_date, @location, @type, @priority, @status, @description, @assigned_officer_id)
  `);

  const cases = [
    { case_id: 1, case_number: 'CASE-2026-0811', title: 'Industrial District Warehouse Fire & Robbery', incident_date: '2026-08-01 22:30:00', reported_date: '2026-08-01 23:15:00', location: 'Pier 42, Harbor Logistics Way', type: 'Robbery', priority: 'High', status: 'Under Investigation', description: 'Armed robbery of high-value electronic cargo followed by deliberate arson to cover tracks.', assigned_officer_id: 7 },
    { case_id: 2, case_number: 'CASE-2026-0814', title: 'Downtown Financial Wire Fraud Extortion', incident_date: '2026-08-03 14:00:00', reported_date: '2026-08-03 16:45:00', location: 'Apex Trust Tower, 450 Financial Ave', type: 'Cybercrime', priority: 'High', status: 'Under Investigation', description: 'Unauthorized diversion of $1.8M corporate payroll via targeted spear-phishing and ransom demand.', assigned_officer_id: 3 },
    { case_id: 3, case_number: 'CASE-2026-0820', title: 'Redline Boulevard Narcotics Distribution Ring', incident_date: '2026-08-05 02:15:00', reported_date: '2026-08-05 03:00:00', location: 'Subway Plaza & Redline Blvd', type: 'Narcotics', priority: 'Critical', status: 'Under Investigation', description: 'Multi-level syndicate distribution hub seized with illegal synthetic substances and unmarked firearms.', assigned_officer_id: 4 },
    { case_id: 4, case_number: 'CASE-2026-0825', title: 'Westside Jewelry Store Heist', incident_date: '2026-07-28 03:40:00', reported_date: '2026-07-28 04:00:00', location: '710 Diamante Row, West End', type: 'Robbery', priority: 'Medium', status: 'Closed - Solved', description: 'Smash-and-grab heist targeting diamond vaults. Two suspects apprehended fleeing in getaway sedan.', assigned_officer_id: 7 },
    { case_id: 5, case_number: 'CASE-2026-0830', title: 'Metropolitan Grand Hotel Homicide', incident_date: '2026-08-10 23:45:00', reported_date: '2026-08-11 00:30:00', location: 'Room 1402, Grand Metropolitan Hotel', type: 'Homicide', priority: 'Critical', status: 'Under Investigation', description: 'Victim found deceased with blunt force trauma and missing encrypted laptop.', assigned_officer_id: 2 },
    { case_id: 6, case_number: 'CASE-2026-0833', title: 'Evidence Locker #4 Tampering Inquiry', incident_date: '2026-08-12 09:00:00', reported_date: '2026-08-12 10:30:00', location: 'Precinct 4 Central Evidence Vault', type: 'Internal Misconduct', priority: 'Critical', status: 'Under Investigation', description: 'Missing confiscated contraband from sealed custody locker #4 during routine inventory audit.', assigned_officer_id: 1 },
    { case_id: 7, case_number: 'CASE-2026-0841', title: 'Greenway Park Armed Assault', incident_date: '2026-08-14 21:10:00', reported_date: '2026-08-14 21:30:00', location: 'North Jogging Trail, Greenway Park', type: 'Assault', priority: 'Medium', status: 'Closed - Solved', description: 'Attempted armed mugging; victim defended themselves and held suspect until patrol units arrived.', assigned_officer_id: 5 },
    { case_id: 8, case_number: 'CASE-2026-0848', title: 'Harbor Cargo Vessel Contraband Smuggling', incident_date: '2026-08-18 01:20:00', reported_date: '2026-08-18 02:00:00', location: 'Berth 17, South Commercial Docks', type: 'Narcotics', priority: 'High', status: 'Open', description: 'Interception of refrigerated cargo container containing concealed illicit pharmaceuticals.', assigned_officer_id: 6 }
  ];

  const insertPersons = db.prepare(`
    INSERT INTO persons (person_id, name, role, national_id, contact, email, address, notes, linked_case_id)
    VALUES (@person_id, @name, @role, @national_id, @contact, @email, @address, @notes, @linked_case_id)
  `);

  const persons = [
    { person_id: 1, name: 'Arthur Pendelton', role: 'Victim', national_id: 'NAT-998231', contact: '+1-555-8811', email: 'a.pendelton@apexcorp.com', address: '124 Summit Ridge Way', notes: 'Chief Security Officer at Apex Cargo Logistics', linked_case_id: 1 },
    { person_id: 2, name: 'Damian "Ghost" Cross', role: 'Suspect', national_id: 'NAT-442109', contact: '+1-555-9922', email: 'dcross99@darkmail.xyz', address: '404 Alleyway B, Docklands', notes: 'Primary suspect in warehouse break-in and cargo hijack', linked_case_id: 1 },
    { person_id: 3, name: 'Victor Vance', role: 'Witness', national_id: 'NAT-771234', contact: '+1-555-3344', email: 'vance.v@harborwatch.org', address: 'Pier 41 Dock Shack', notes: 'Dock master on night duty who witnessed getaway van', linked_case_id: 1 },
    { person_id: 4, name: 'Rachel Sterling', role: 'Victim', national_id: 'NAT-551982', contact: '+1-555-4421', email: 'rachel.s@apextrust.com', address: '880 Skyview Penthouse', notes: 'Apex Trust VP targeted by spear-phishing extortion', linked_case_id: 2 },
    { person_id: 5, name: 'Felix Kozlov', role: 'Suspect', national_id: 'NAT-663812', contact: '+1-555-7788', email: 'felix.k@cryptonet.ru', address: 'Unknown / Overseas Proxy', notes: 'Hacker handle "CipherShadow", linked to extortion crypto wallets', linked_case_id: 2 },
    { person_id: 6, name: 'Hector "Rico" Santos', role: 'Suspect', national_id: 'NAT-119283', contact: '+1-555-5544', email: 'rico.santos@eastside.net', address: '312 Elm Street, Apt 4B', notes: 'Mid-level distributor arrested on Redline Blvd with contraband', linked_case_id: 3 },
    { person_id: 7, name: 'Carlos Mendez', role: 'Informant', national_id: 'NAT-882711', contact: '+1-555-1100', email: 'c.mendez@secureline.org', address: 'Classified Location', notes: 'Confidential informant providing dropsite intel', linked_case_id: 3 },
    { person_id: 8, name: 'Gary Higgins', role: 'Suspect', national_id: 'NAT-334912', contact: '+1-555-6677', email: 'ghiggins@freemail.com', address: '52 Oakridge Drive', notes: 'Apprehended driver during Westside Jewelry robbery', linked_case_id: 4 },
    { person_id: 9, name: 'Derrick Vance', role: 'Suspect', national_id: 'NAT-334913', contact: '+1-555-6678', email: 'dvance.craft@freemail.com', address: '54 Oakridge Drive', notes: 'Accomplice in Westside jewelry vault breach', linked_case_id: 4 },
    { person_id: 10, name: 'Helena Troy', role: 'Victim', national_id: 'NAT-901238', contact: '+1-555-2233', email: 'h.troy@aerotech.com', address: 'Grand Metropolitan Hotel #1402', notes: 'Deceased defense contractor executive', linked_case_id: 5 },
    { person_id: 11, name: 'Julian Drake', role: 'Suspect', national_id: 'NAT-774411', contact: '+1-555-4455', email: 'jdrake@shadowcapital.co', address: '200 Waterfront Luxury Lofts', notes: 'Business rival seen leaving room 1402 on CCTV', linked_case_id: 5 },
    { person_id: 12, name: 'Officer David Cole', role: 'Suspect', national_id: 'BADGE-405', contact: '+1-555-0455', email: 'd.cole@metropolice.gov', address: 'Precinct Locker #12', notes: 'Officer under inquiry for unlogged vault access', linked_case_id: 6 },
    { person_id: 13, name: 'Jessica Huang', role: 'Victim', national_id: 'NAT-228192', contact: '+1-555-8833', email: 'j.huang@cityuni.edu', address: '910 University Ave', notes: 'Student attacked while jogging in Greenway Park', linked_case_id: 7 },
    { person_id: 14, name: 'Braden Thorne', role: 'Suspect', national_id: 'NAT-665123', contact: '+1-555-9900', email: 'bthorne@nomail.com', address: 'Transient / Downtown Shelter', notes: 'Perpetrator apprehended at scene of Greenway assault', linked_case_id: 7 }
  ];

  const insertArrests = db.prepare(`
    INSERT INTO arrests (arrest_id, person_id, case_id, officer_id, charges, arrest_date, booking_status, bail_amount, facility_location)
    VALUES (@arrest_id, @person_id, @case_id, @officer_id, @charges, @arrest_date, @booking_status, @bail_amount, @facility_location)
  `);

  const arrests = [
    { arrest_id: 1, person_id: 6, case_id: 3, officer_id: 4, charges: 'Possession of Schedule I Controlled Substance with Intent to Distribute; Illegal Firearm Possession', arrest_date: '2026-08-05 04:30:00', booking_status: 'In Custody', bail_amount: 250000.00, facility_location: 'Metro High Security Ward 2' },
    { arrest_id: 2, person_id: 8, case_id: 4, officer_id: 7, charges: 'Grand Larceny; Commercial Burglary; Evading Law Enforcement', arrest_date: '2026-07-28 05:15:00', booking_status: 'Awaiting Trial', bail_amount: 75000.00, facility_location: 'Central Processing Facility' },
    { arrest_id: 3, person_id: 9, case_id: 4, officer_id: 7, charges: 'Grand Larceny; Possession of Burglary Tools; Conspiracy to Commit Robbery', arrest_date: '2026-07-28 05:20:00', booking_status: 'Released on Bail', bail_amount: 50000.00, facility_location: 'Central Processing Facility' },
    { arrest_id: 4, person_id: 14, case_id: 7, officer_id: 5, charges: 'Attempted Robbery with Deadly Weapon; Aggravated Battery', arrest_date: '2026-08-14 22:00:00', booking_status: 'In Custody', bail_amount: 100000.00, facility_location: 'North Precinct Holding Cell 3' }
  ];

  const insertEvidence = db.prepare(`
    INSERT INTO evidence (evidence_id, case_id, item_name, description, evidence_type, storage_location, collected_date, chain_of_custody, status)
    VALUES (@evidence_id, @case_id, @item_name, @description, @evidence_type, @storage_location, @collected_date, @chain_of_custody, @status)
  `);

  const evidence = [
    { evidence_id: 1, case_id: 1, item_name: 'Thermal Cutting Torch & Fuel Canister', description: 'Industrial-grade oxy-acetylene torch found abandoned near Pier 42 breach point', evidence_type: 'Physical', storage_location: 'Vault A - Locker 102', collected_date: '2026-08-02 01:10:00', chain_of_custody: 'Officer Jenkins -> Det. Mercer -> Forensics Locker', status: 'In Vault' },
    { evidence_id: 2, case_id: 1, item_name: 'Burned Server Hard Drive', description: 'Recovered from scorched security shack. Sent for digital recovery.', evidence_type: 'Digital', storage_location: 'Cyber Forensics Lab 4', collected_date: '2026-08-02 02:30:00', chain_of_custody: 'Det. Mercer -> Det. Rostova (Cyber Lab)', status: 'In Forensics Lab' },
    { evidence_id: 3, case_id: 2, item_name: 'Ransomware Decryption Note & USB Beacon', description: 'SanDisk 32GB drive containing payload script "ShadowLock_v3.bin"', evidence_type: 'Digital', storage_location: 'Cyber Forensics Lab 2', collected_date: '2026-08-03 17:30:00', chain_of_custody: 'Det. Rostova -> Lead Analyst Chen', status: 'In Forensics Lab' },
    { evidence_id: 4, case_id: 3, item_name: 'Seized Narcotics Package (2.4 kg)', description: 'Heat-sealed brick marked with scorpion emblem tested positive for synthetic opioids', evidence_type: 'Narcotics', storage_location: 'Narcotics Secure Vault - Safe 09', collected_date: '2026-08-05 05:00:00', chain_of_custody: 'Sgt. Cole -> Property Clerk Adams', status: 'In Vault' },
    { evidence_id: 5, case_id: 3, item_name: 'Glock 19 9mm Pistol (Obliterated Serial)', description: 'Loaded handgun with extended 33-round magazine recovered from suspect waist', evidence_type: 'Ballistics', storage_location: 'Ballistics Locker B-14', collected_date: '2026-08-05 05:15:00', chain_of_custody: 'Sgt. Cole -> Ballistics Unit', status: 'In Vault' },
    { evidence_id: 6, case_id: 4, item_name: 'Stolen Diamond Necklaces (Qty: 18)', description: 'Total appraised value $420,000 recovered from trunk of getaway sedan', evidence_type: 'Physical', storage_location: 'High-Value Vault - Safe 01', collected_date: '2026-07-28 06:00:00', chain_of_custody: 'Det. Mercer -> Property Clerk Adams', status: 'In Vault' },
    { evidence_id: 7, case_id: 5, item_name: 'Hotel Keycard Access Log & Fingerprint Swabs', description: 'Digital audit log showing room 1402 unlock times; 4 latent prints lifted from door handle', evidence_type: 'Documentary', storage_location: 'Forensics Unit Desk 03', collected_date: '2026-08-11 02:00:00', chain_of_custody: 'Det. Brody -> Det. Bennett', status: 'In Forensics Lab' },
    { evidence_id: 8, case_id: 7, item_name: 'Tactical Folding Knife (4-inch blade)', description: 'Used during Greenway Park robbery attempt. Blood traces on hilt matched suspect.', evidence_type: 'Physical', storage_location: 'Vault C - Locker 44', collected_date: '2026-08-14 22:30:00', chain_of_custody: 'Officer Jenkins -> Property Desk', status: 'Presented in Court' }
  ];

  const insertComplaints = db.prepare(`
    INSERT INTO complaints (complaint_id, complaint_number, officer_id, complainant_name, complainant_contact, incident_date, filed_date, allegation_type, severity, description, status, investigator_notes, disciplinary_action)
    VALUES (@complaint_id, @complaint_number, @officer_id, @complainant_name, @complainant_contact, @incident_date, @filed_date, @allegation_type, @severity, @description, @status, @investigator_notes, @disciplinary_action)
  `);

  const complaints = [
    { complaint_id: 1, complaint_number: 'IA-2026-0041', officer_id: 4, complainant_name: 'Sergeant Rebecca Diaz (Audit Officer)', complainant_contact: '+1-555-0104', incident_date: '2026-08-11', filed_date: '2026-08-12', allegation_type: 'Procedural Violation', severity: 'Critical', description: 'Unauthorized access to Narcotics Vault safe 09 during non-operational hours; discrepancy in seized cash envelope.', status: 'Under Investigation', investigator_notes: 'Security badge log shows Sgt. Cole accessed vault at 03:41 AM without co-signer.', disciplinary_action: 'Pending Hearing - Suspended from Active Duty' },
    { complaint_id: 2, complaint_number: 'IA-2026-0038', officer_id: 5, complainant_name: 'Citizen Gregory Lawson', complainant_contact: '+1-555-6622', incident_date: '2026-07-15', filed_date: '2026-07-16', allegation_type: 'Unlawful Search', severity: 'Low', description: 'Complainant claimed vehicle trunk was searched without probable cause during traffic checkpoint.', status: 'Exonerated (Cleared)', investigator_notes: 'Body camera footage reviewed: driver gave verbal consent on video tape.', disciplinary_action: 'None - Cleared' },
    { complaint_id: 3, complaint_number: 'IA-2026-0029', officer_id: 8, complainant_name: 'Citizen Aaron Miller', complainant_contact: '+1-555-7733', incident_date: '2026-06-20', filed_date: '2026-06-22', allegation_type: 'Excessive Force', severity: 'Medium', description: 'Complainant alleged rough handling during detention outside nightlife district club.', status: 'Unfounded / Dismissed', investigator_notes: 'Surveillance video revealed complainant actively resisted and attempted to strike arresting officer.', disciplinary_action: 'None - Dismissed' },
    { complaint_id: 4, complaint_number: 'IA-2026-0044', officer_id: 10, complainant_name: 'Driver Karen Walsh', complainant_contact: '+1-555-9944', incident_date: '2026-08-08', filed_date: '2026-08-09', allegation_type: 'Dereliction of Duty', severity: 'Low', description: 'Allegation of aggressive tone during speeding citation on highway 101.', status: 'Pending Review', investigator_notes: 'Awaiting supervisor dashcam audio review.', disciplinary_action: null }
  ];

  const transaction = db.transaction(() => {
    officers.forEach(o => insertOfficer.run(o));
    cases.forEach(c => insertCases.run(c));
    persons.forEach(p => insertPersons.run(p));
    arrests.forEach(a => insertArrests.run(a));
    evidence.forEach(e => insertEvidence.run(e));
    complaints.forEach(cp => insertComplaints.run(cp));
  });

  transaction();
  console.log('Police Affairs Database Initialized & Seeded Successfully.');
}

initDatabase();

module.exports = db;
