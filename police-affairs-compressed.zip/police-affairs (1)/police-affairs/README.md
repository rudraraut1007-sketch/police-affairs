# 🚔 POLICE AFFAIRS & INTERNAL AFFAIRS DBMS PORTAL

A full-stack, enterprise-grade Database Management System (DBMS) and Tactical Command Portal for Police Operations & Internal Affairs.

---

## 🏛️ Database Architecture & Core Tables

The system implements 6 interconnected relational tables with full 3rd Normal Form (3NF) compliance and referential integrity:

1. **`officers`** — Law enforcement personnel, badges, ranks, departments, contact, shift, and duty status.
2. **`cases` / `incidents`** — Crime incidents, priority levels, investigation status, dates, and assigned lead officer foreign key (`assigned_officer_id`).
3. **`persons`** — Victims, witnesses, informants, and suspects linked to active incident records (`linked_case_id`).
4. **`arrests`** — Custodial bookings, statutory charges, bail amounts, and arresting officer foreign keys.
5. **`evidence`** — Forensic vault items, storage lockers, and chain-of-custody logs (`case_id`).
6. **`complaints`** — Internal Affairs misconduct tracking, citizen grievances, severity index, and inquiry statuses (`officer_id`).

---

## 🚀 Quick Start (One-Click Launch)

### Prerequisites:
- Node.js (v18+)

### Step 1: Start Backend Server
```bash
cd server
npm install
npm start
```
*API runs on `http://localhost:5000` with embedded SQLite (zero config needed) + automatic schema and seed initialization.*

### Step 2: Start Frontend Web Portal
```bash
cd client
npm install
npm run dev
```
*Open your browser at `http://localhost:5173` to access the Police Affairs Tactical Command Portal.*

---

## 💾 MySQL Export & Import Instructions

1. Open the web portal and click **"Export MySQL .sql"** in the top navigation or from the SQL Query Console.
2. Or locate the pre-built pure MySQL scripts in `/database/`:
   - `database/schema_mysql.sql` — MySQL DDL schema with Foreign Keys, Triggers, Views, and Indexes.
   - `database/seed_mysql.sql` — Rich realistic dataset with 10+ officers, 20+ cases, suspects, and IA complaints.
   - `database/queries.sql` — Academic & operational DBMS queries (Joins, Aggregations, Subqueries).
3. Import into **MySQL Workbench**, **phpMyAdmin**, or command-line:
```bash
mysql -u root -p < database/schema_mysql.sql
mysql -u root -p < database/seed_mysql.sql
```

---

## 🎨 UI/UX Features (Tactical Cyber Theme)
- **High-Tech Dashboard**: Cyber gauges, Segmented Battery/Integrity index, Golden Amber Incident Wave sparkline.
- **Interactive Object Browser & Inspector**: Drill-down into live relational properties of any record.
- **Dedicated Incident & Operations Logs**: Cases, Officers Roster, Persons of Interest, Custody Bookings, Evidence Vault, and Internal Affairs misbehavior tracking.

