-- =============================================================================
-- POLICE AFFAIRS & INTERNAL AFFAIRS DATABASE MANAGEMENT SYSTEM
-- Compatible with MySQL 8.0+ / MariaDB / SQLite Relational Standards
-- =============================================================================

CREATE DATABASE IF NOT EXISTS `police_affairs_db` 
CHARACTER SET utf8mb4 
COLLATE utf8mb4_unicode_ci;

USE `police_affairs_db`;

-- Drop tables in reverse order of foreign key dependency
DROP TABLE IF EXISTS `complaints`;
DROP TABLE IF EXISTS `evidence`;
DROP TABLE IF EXISTS `arrests`;
DROP TABLE IF EXISTS `persons`;
DROP TABLE IF EXISTS `cases`;
DROP TABLE IF EXISTS `officers`;

-- =============================================================================
-- 1. OFFICERS TABLE
-- Tracks all law enforcement personnel and their internal affairs standing
-- =============================================================================
CREATE TABLE `officers` (
    `officer_id` INT AUTO_INCREMENT PRIMARY KEY,
    `badge_number` VARCHAR(20) NOT NULL UNIQUE,
    `name` VARCHAR(100) NOT NULL,
    `rank` VARCHAR(50) NOT NULL,
    `department` VARCHAR(80) NOT NULL,
    `contact` VARCHAR(30) NOT NULL,
    `email` VARCHAR(100) NOT NULL UNIQUE,
    `hire_date` DATE NOT NULL,
    `status` ENUM('Active', 'On Leave', 'Suspended', 'Retired', 'Under Investigation') DEFAULT 'Active',
    `shift` ENUM('Day', 'Evening', 'Night', 'Rotating') DEFAULT 'Day',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_officer_dept` (`department`),
    INDEX `idx_officer_rank` (`rank`),
    INDEX `idx_officer_status` (`status`)
) ENGINE=InnoDB;

-- =============================================================================
-- 2. CASES / INCIDENTS TABLE
-- Represents reported crimes, open investigations, and incident reports
-- =============================================================================
CREATE TABLE `cases` (
    `case_id` INT AUTO_INCREMENT PRIMARY KEY,
    `case_number` VARCHAR(30) NOT NULL UNIQUE,
    `title` VARCHAR(200) NOT NULL,
    `incident_date` DATETIME NOT NULL,
    `reported_date` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `location` VARCHAR(255) NOT NULL,
    `type` VARCHAR(80) NOT NULL, -- e.g., Homicide, Cybercrime, Narcotics, Robbery, Internal Misconduct
    `priority` ENUM('Low', 'Medium', 'High', 'Critical') DEFAULT 'Medium',
    `status` ENUM('Open', 'Under Investigation', 'Pending Review', 'Closed - Solved', 'Closed - Unsolved') DEFAULT 'Open',
    `description` TEXT,
    `assigned_officer_id` INT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT `fk_cases_assigned_officer` 
        FOREIGN KEY (`assigned_officer_id`) 
        REFERENCES `officers` (`officer_id`) 
        ON DELETE SET NULL 
        ON UPDATE CASCADE,
    INDEX `idx_cases_status` (`status`),
    INDEX `idx_cases_type` (`type`),
    INDEX `idx_cases_date` (`incident_date`)
) ENGINE=InnoDB;

-- =============================================================================
-- 3. PERSONS TABLE
-- Records victims, witnesses, suspects, and persons of interest linked to cases
-- =============================================================================
CREATE TABLE `persons` (
    `person_id` INT AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(100) NOT NULL,
    `role` ENUM('Victim', 'Witness', 'Suspect', 'Person of Interest', 'Informant') NOT NULL,
    `national_id` VARCHAR(50) NULL,
    `contact` VARCHAR(30) NULL,
    `email` VARCHAR(100) NULL,
    `address` VARCHAR(255) NULL,
    `notes` TEXT,
    `linked_case_id` INT NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_persons_linked_case` 
        FOREIGN KEY (`linked_case_id`) 
        REFERENCES `cases` (`case_id`) 
        ON DELETE CASCADE 
        ON UPDATE CASCADE,
    INDEX `idx_persons_role` (`role`),
    INDEX `idx_persons_name` (`name`)
) ENGINE=InnoDB;

-- =============================================================================
-- 4. ARRESTS TABLE
-- Details of custodial bookings, charges filed, and arresting officers
-- =============================================================================
CREATE TABLE `arrests` (
    `arrest_id` INT AUTO_INCREMENT PRIMARY KEY,
    `person_id` INT NOT NULL,
    `case_id` INT NOT NULL,
    `officer_id` INT NOT NULL,
    `charges` TEXT NOT NULL,
    `arrest_date` DATETIME NOT NULL,
    `booking_status` ENUM('In Custody', 'Released on Bail', 'Transferred to Prison', 'Charges Dropped', 'Awaiting Trial') DEFAULT 'In Custody',
    `bail_amount` DECIMAL(10, 2) DEFAULT 0.00,
    `facility_location` VARCHAR(100) DEFAULT 'Central Processing Facility',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_arrests_person` 
        FOREIGN KEY (`person_id`) 
        REFERENCES `persons` (`person_id`) 
        ON DELETE RESTRICT 
        ON UPDATE CASCADE,
    CONSTRAINT `fk_arrests_case` 
        FOREIGN KEY (`case_id`) 
        REFERENCES `cases` (`case_id`) 
        ON DELETE CASCADE 
        ON UPDATE CASCADE,
    CONSTRAINT `fk_arrests_officer` 
        FOREIGN KEY (`officer_id`) 
        REFERENCES `officers` (`officer_id`) 
        ON DELETE RESTRICT 
        ON UPDATE CASCADE,
    INDEX `idx_arrests_date` (`arrest_date`),
    INDEX `idx_arrests_status` (`booking_status`)
) ENGINE=InnoDB;

-- =============================================================================
-- 5. EVIDENCE TABLE
-- Forensic and physical chain-of-custody tracking in police vaults
-- =============================================================================
CREATE TABLE `evidence` (
    `evidence_id` INT AUTO_INCREMENT PRIMARY KEY,
    `case_id` INT NOT NULL,
    `item_name` VARCHAR(150) NOT NULL,
    `description` TEXT NOT NULL,
    `evidence_type` ENUM('Physical', 'Digital', 'Biological/DNA', 'Ballistics', 'Documentary', 'Narcotics', 'Other') DEFAULT 'Physical',
    `storage_location` VARCHAR(100) NOT NULL, -- e.g. Vault B - Locker 14, Cold Storage 03
    `collected_date` DATETIME NOT NULL,
    `chain_of_custody` TEXT, -- Log of custody transfers
    `status` ENUM('In Vault', 'In Forensics Lab', 'Presented in Court', 'Disposed / Returned') DEFAULT 'In Vault',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_evidence_case` 
        FOREIGN KEY (`case_id`) 
        REFERENCES `cases` (`case_id`) 
        ON DELETE CASCADE 
        ON UPDATE CASCADE,
    INDEX `idx_evidence_type` (`evidence_type`),
    INDEX `idx_evidence_location` (`storage_location`)
) ENGINE=InnoDB;

-- =============================================================================
-- 6. COMPLAINTS (INTERNAL AFFAIRS) TABLE
-- Misconduct inquiries, citizen grievances, and integrity investigations
-- =============================================================================
CREATE TABLE `complaints` (
    `complaint_id` INT AUTO_INCREMENT PRIMARY KEY,
    `complaint_number` VARCHAR(30) NOT NULL UNIQUE,
    `officer_id` INT NOT NULL,
    `complainant_name` VARCHAR(100) NOT NULL,
    `complainant_contact` VARCHAR(50) NULL,
    `incident_date` DATE NOT NULL,
    `filed_date` DATE NOT NULL,
    `allegation_type` ENUM('Excessive Force', 'Misconduct', 'Corruption / Bribery', 'Dereliction of Duty', 'Harassment', 'Procedural Violation', 'Unlawful Search') NOT NULL,
    `severity` ENUM('Low', 'Medium', 'High', 'Critical') DEFAULT 'Medium',
    `description` TEXT NOT NULL,
    `status` ENUM('Pending Review', 'Under Investigation', 'Sustained (Guilty)', 'Exonerated (Cleared)', 'Unfounded / Dismissed') DEFAULT 'Under Investigation',
    `investigator_notes` TEXT,
    `disciplinary_action` VARCHAR(255) NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT `fk_complaints_officer` 
        FOREIGN KEY (`officer_id`) 
        REFERENCES `officers` (`officer_id`) 
        ON DELETE CASCADE 
        ON UPDATE CASCADE,
    INDEX `idx_complaints_status` (`status`),
    INDEX `idx_complaints_severity` (`severity`),
    INDEX `idx_complaints_officer` (`officer_id`)
) ENGINE=InnoDB;

-- =============================================================================
-- DATABASE VIEWS (For quick reporting & complex analytics)
-- =============================================================================

-- View 1: 360-degree Case Overview with Officer, Counts of Evidence, Suspects, and Arrests
CREATE OR REPLACE VIEW `vw_case_summary` AS
SELECT 
    c.case_id,
    c.case_number,
    c.title,
    c.incident_date,
    c.location,
    c.type,
    c.priority,
    c.status,
    o.name AS assigned_officer_name,
    o.badge_number AS assigned_officer_badge,
    o.rank AS assigned_officer_rank,
    (SELECT COUNT(*) FROM persons p WHERE p.linked_case_id = c.case_id) AS total_persons_involved,
    (SELECT COUNT(*) FROM persons p WHERE p.linked_case_id = c.case_id AND p.role = 'Suspect') AS total_suspects,
    (SELECT COUNT(*) FROM evidence e WHERE e.case_id = c.case_id) AS total_evidence_items,
    (SELECT COUNT(*) FROM arrests a WHERE a.case_id = c.case_id) AS total_arrests
FROM cases c
LEFT JOIN officers o ON c.assigned_officer_id = o.officer_id;

-- View 2: Officer Workload and Internal Affairs Integrity Profile
CREATE OR REPLACE VIEW `vw_officer_integrity_profile` AS
SELECT 
    o.officer_id,
    o.badge_number,
    o.name,
    o.rank,
    o.department,
    o.status,
    COUNT(DISTINCT c.case_id) AS total_assigned_cases,
    COUNT(DISTINCT CASE WHEN c.status LIKE '%Closed%' THEN c.case_id END) AS solved_cases,
    COUNT(DISTINCT a.arrest_id) AS total_arrests_made,
    COUNT(DISTINCT comp.complaint_id) AS total_ia_complaints,
    COUNT(DISTINCT CASE WHEN comp.status = 'Sustained (Guilty)' THEN comp.complaint_id END) AS sustained_misconduct_count
FROM officers o
LEFT JOIN cases c ON o.officer_id = c.assigned_officer_id
LEFT JOIN arrests a ON o.officer_id = a.officer_id
LEFT JOIN complaints comp ON o.officer_id = comp.officer_id
GROUP BY o.officer_id, o.badge_number, o.name, o.rank, o.department, o.status;

-- =============================================================================
-- TRIGGERS (Automated integrity and workflow rules)
-- =============================================================================

DELIMITER $$

-- Trigger: If an officer receives a High/Critical severity complaint sustained, mark officer as 'Under Investigation' or 'Suspended'
CREATE TRIGGER `trg_complaint_severity_alert`
AFTER INSERT ON `complaints`
FOR EACH ROW
BEGIN
    IF NEW.severity = 'Critical' THEN
        UPDATE `officers` 
        SET `status` = 'Under Investigation' 
        WHERE `officer_id` = NEW.officer_id AND `status` = 'Active';
    END IF;
END$$

DELIMITER ;
