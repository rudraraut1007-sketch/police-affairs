-- =============================================================================
-- POLICE AFFAIRS & INTERNAL AFFAIRS - DBMS ADVANCED QUERIES
-- Comprehensive SQL query suite for academic submissions & operations
-- =============================================================================

USE `police_affairs_db`;

-- -----------------------------------------------------------------------------
-- Query 1: Complete Case Dossier (4-Table INNER & LEFT JOIN)
-- Retrieves case details, assigned officer, involved persons, and evidence count
-- -----------------------------------------------------------------------------
SELECT 
    c.case_number,
    c.title AS case_title,
    c.type AS crime_type,
    c.priority,
    c.status AS case_status,
    CONCAT(o.rank, ' ', o.name, ' (', o.badge_number, ')') AS lead_investigator,
    p.name AS person_name,
    p.role AS person_role,
    (SELECT COUNT(*) FROM evidence e WHERE e.case_id = c.case_id) AS total_evidence_items
FROM cases c
JOIN officers o ON c.assigned_officer_id = o.officer_id
LEFT JOIN persons p ON c.case_id = p.linked_case_id
ORDER BY c.priority DESC, c.incident_date DESC;

-- -----------------------------------------------------------------------------
-- Query 2: Arrest Records with Accused & Arresting Officer Info (3-Table JOIN)
-- -----------------------------------------------------------------------------
SELECT 
    a.arrest_id,
    p.name AS accused_person,
    p.national_id,
    c.case_number,
    c.title AS case_title,
    a.charges,
    a.arrest_date,
    a.booking_status,
    CONCAT('$', FORMAT(a.bail_amount, 2)) AS bail_amount_formatted,
    CONCAT(o.name, ' [', o.badge_number, ']') AS arresting_officer,
    a.facility_location
FROM arrests a
JOIN persons p ON a.person_id = p.person_id
JOIN cases c ON a.case_id = c.case_id
JOIN officers o ON a.officer_id = o.officer_id
ORDER BY a.arrest_date DESC;

-- -----------------------------------------------------------------------------
-- Query 3: Officer Caseload & Disciplinary Risk Aggregation (GROUP BY + HAVING)
-- Identifies active officers carrying more than 1 case who also have IA complaints
-- -----------------------------------------------------------------------------
SELECT 
    o.officer_id,
    o.badge_number,
    o.name AS officer_name,
    o.rank,
    o.department,
    o.status AS duty_status,
    COUNT(DISTINCT c.case_id) AS active_cases_count,
    COUNT(DISTINCT comp.complaint_id) AS total_complaints_filed
FROM officers o
LEFT JOIN cases c ON o.officer_id = c.assigned_officer_id AND c.status != 'Closed - Solved'
LEFT JOIN complaints comp ON o.officer_id = comp.officer_id
GROUP BY o.officer_id, o.badge_number, o.name, o.rank, o.department, o.status
HAVING active_cases_count >= 1
ORDER BY total_complaints_filed DESC, active_cases_count DESC;

-- -----------------------------------------------------------------------------
-- Query 4: Unsolved High-Priority Incidents with Seized Evidence (Correlated Subquery)
-- -----------------------------------------------------------------------------
SELECT 
    c.case_number,
    c.title,
    c.priority,
    c.location,
    c.incident_date
FROM cases c
WHERE c.priority IN ('High', 'Critical')
  AND c.status NOT LIKE 'Closed%'
  AND EXISTS (
      SELECT 1 FROM evidence e 
      WHERE e.case_id = c.case_id 
        AND e.status IN ('In Vault', 'In Forensics Lab')
  );

-- -----------------------------------------------------------------------------
-- Query 5: Evidence Vault Inventory by Storage Locker & Type
-- -----------------------------------------------------------------------------
SELECT 
    e.storage_location,
    e.evidence_type,
    COUNT(*) AS total_items,
    GROUP_CONCAT(e.item_name SEPARATOR ' | ') AS stored_items_summary
FROM evidence e
GROUP BY e.storage_location, e.evidence_type
ORDER BY e.storage_location ASC;

-- -----------------------------------------------------------------------------
-- Query 6: Internal Affairs Summary by Allegation Type & Outcome
-- -----------------------------------------------------------------------------
SELECT 
    comp.allegation_type,
    COUNT(*) AS total_allegations,
    SUM(CASE WHEN comp.status = 'Sustained (Guilty)' THEN 1 ELSE 0 END) AS sustained_count,
    SUM(CASE WHEN comp.status = 'Exonerated (Cleared)' THEN 1 ELSE 0 END) AS cleared_count,
    SUM(CASE WHEN comp.status = 'Under Investigation' THEN 1 ELSE 0 END) AS pending_inquiry_count
FROM complaints comp
GROUP BY comp.allegation_type
ORDER BY total_allegations DESC;
