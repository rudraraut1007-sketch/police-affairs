-- =============================================================================
-- POLICE AFFAIRS & INTERNAL AFFAIRS SEED DATA
-- =============================================================================

USE `police_affairs_db`;

-- 1. SEED OFFICERS
INSERT INTO `officers` (`officer_id`, `badge_number`, `name`, `rank`, `department`, `contact`, `email`, `hire_date`, `status`, `shift`) VALUES
(1, 'BADGE-104', 'Captain James Vance', 'Captain', 'Internal Affairs Division', '+1-555-0199', 'j.vance@metropolice.gov', '2012-04-15', 'Active', 'Day'),
(2, 'BADGE-219', 'Detective Marcus Brody', 'Detective First Grade', 'Homicide Division', '+1-555-0211', 'm.brody@metropolice.gov', '2015-08-20', 'Active', 'Day'),
(3, 'BADGE-342', 'Detective Elena Rostova', 'Senior Detective', 'Cyber & Financial Crimes', '+1-555-0344', 'e.rostova@metropolice.gov', '2018-01-10', 'Active', 'Evening'),
(4, 'BADGE-405', 'Sergeant David Cole', 'Sergeant', 'Major Narcotics Unit', '+1-555-0455', 'd.cole@metropolice.gov', '2016-11-05', 'Under Investigation', 'Night'),
(5, 'BADGE-512', 'Officer Sarah Jenkins', 'Patrol Officer', 'Patrol & Field Ops', '+1-555-0588', 's.jenkins@metropolice.gov', '2021-03-22', 'Active', 'Rotating'),
(6, 'BADGE-630', 'Lieutenant Frank Sterling', 'Lieutenant', 'Special Investigations', '+1-555-0677', 'f.sterling@metropolice.gov', '2010-09-01', 'Active', 'Day'),
(7, 'BADGE-718', 'Detective Alex Mercer', 'Detective', 'Robbery & Burglary', '+1-555-0722', 'a.mercer@metropolice.gov', '2019-06-14', 'Active', 'Day'),
(8, 'BADGE-809', 'Officer Malik Reed', 'Patrol Officer', 'Patrol & Field Ops', '+1-555-0899', 'm.reed@metropolice.gov', '2022-02-18', 'Active', 'Night'),
(9, 'BADGE-921', 'Detective Chloe Bennett', 'Detective', 'Forensic & Evidence Unit', '+1-555-0944', 'c.bennett@metropolice.gov', '2017-05-30', 'Active', 'Day'),
(10, 'BADGE-990', 'Officer Tyler Vance', 'Patrol Officer', 'Traffic Enforcement', '+1-555-0991', 't.vance@metropolice.gov', '2023-01-12', 'Active', 'Rotating');

-- 2. SEED CASES
INSERT INTO `cases` (`case_id`, `case_number`, `title`, `incident_date`, `reported_date`, `location`, `type`, `priority`, `status`, `description`, `assigned_officer_id`) VALUES
(1, 'CASE-2026-0811', 'Industrial District Warehouse Fire & Robbery', '2026-08-01 22:30:00', '2026-08-01 23:15:00', 'Pier 42, Harbor Logistics Way', 'Robbery', 'High', 'Under Investigation', 'Armed robbery of high-value electronic cargo followed by deliberate arson to cover tracks.', 7),
(2, 'CASE-2026-0814', 'Downtown Financial Wire Fraud Extortion', '2026-08-03 14:00:00', '2026-08-03 16:45:00', 'Apex Trust Tower, 450 Financial Ave', 'Cybercrime', 'High', 'Under Investigation', 'Unauthorized diversion of $1.8M corporate payroll via targeted spear-phishing and ransom demand.', 3),
(3, 'CASE-2026-0820', 'Redline Boulevard Narcotics Distribution Ring', '2026-08-05 02:15:00', '2026-08-05 03:00:00', 'Subway Plaza & Redline Blvd', 'Narcotics', 'Critical', 'Under Investigation', 'Multi-level syndicate distribution hub seized with illegal synthetic substances and unmarked firearms.', 4),
(4, 'CASE-2026-0825', 'Westside Jewelry Store Heist', '2026-07-28 03:40:00', '2026-07-28 04:00:00', '710 Diamante Row, West End', 'Robbery', 'Medium', 'Closed - Solved', 'Smash-and-grab heist targeting diamond vaults. Two suspects apprehended fleeing in getaway sedan.', 7),
(5, 'CASE-2026-0830', 'Metropolitan Grand Hotel Homicide', '2026-08-10 23:45:00', '2026-08-11 00:30:00', 'Room 1402, Grand Metropolitan Hotel', 'Homicide', 'Critical', 'Under Investigation', 'Victim found deceased with blunt force trauma and missing encrypted laptop.', 2),
(6, 'CASE-2026-0833', 'Evidence Locker #4 Tampering Inquiry', '2026-08-12 09:00:00', '2026-08-12 10:30:00', 'Precinct 4 Central Evidence Vault', 'Internal Misconduct', 'Critical', 'Under Investigation', 'Missing confiscated contraband from sealed custody locker #4 during routine inventory audit.', 1),
(7, 'CASE-2026-0841', 'Greenway Park Armed Assault', '2026-08-14 21:10:00', '2026-08-14 21:30:00', 'North Jogging Trail, Greenway Park', 'Assault', 'Medium', 'Closed - Solved', 'Attempted armed mugging; victim defended themselves and held suspect until patrol units arrived.', 5),
(8, 'CASE-2026-0848', 'Harbor Cargo Vessel Contraband Smuggling', '2026-08-18 01:20:00', '2026-08-18 02:00:00', 'Berth 17, South Commercial Docks', 'Narcotics', 'High', 'Open', 'Interception of refrigerated cargo container containing concealed illicit pharmaceuticals.', 6);

-- 3. SEED PERSONS
INSERT INTO `persons` (`person_id`, `name`, `role`, `national_id`, `contact`, `email`, `address`, `notes`, `linked_case_id`) VALUES
(1, 'Arthur Pendelton', 'Victim', 'NAT-998231', '+1-555-8811', 'a.pendelton@apexcorp.com', '124 Summit Ridge Way', 'Chief Security Officer at Apex Cargo Logistics', 1),
(2, 'Damian "Ghost" Cross', 'Suspect', 'NAT-442109', '+1-555-9922', 'dcross99@darkmail.xyz', '404 Alleyway B, Docklands', 'Primary suspect in warehouse break-in and cargo hijack', 1),
(3, 'Victor Vance', 'Witness', 'NAT-771234', '+1-555-3344', 'vance.v@harborwatch.org', 'Pier 41 Dock Shack', 'Dock master on night duty who witnessed getaway van', 1),
(4, 'Rachel Sterling', 'Victim', 'NAT-551982', '+1-555-4421', 'rachel.s@apextrust.com', '880 Skyview Penthouse', 'Apex Trust VP targeted by spear-phishing extortion', 2),
(5, 'Felix Kozlov', 'Suspect', 'NAT-663812', '+1-555-7788', 'felix.k@cryptonet.ru', 'Unknown / Overseas Proxy', 'Hacker handle "CipherShadow", linked to extortion crypto wallets', 2),
(6, 'Hector "Rico" Santos', 'Suspect', 'NAT-119283', '+1-555-5544', 'rico.santos@eastside.net', '312 Elm Street, Apt 4B', 'Mid-level distributor arrested on Redline Blvd with contraband', 3),
(7, 'Carlos Mendez', 'Informant', 'NAT-882711', '+1-555-1100', 'c.mendez@secureline.org', 'Classified Location', 'Confidential informant providing dropsite intel', 3),
(8, 'Gary Higgins', 'Suspect', 'NAT-334912', '+1-555-6677', 'ghiggins@freemail.com', '52 Oakridge Drive', 'Apprehended driver during Westside Jewelry robbery', 4),
(9, 'Derrick Vance', 'Suspect', 'NAT-334913', '+1-555-6678', 'dvance.craft@freemail.com', '54 Oakridge Drive', 'Accomplice in Westside jewelry vault breach', 4),
(10, 'Helena Troy', 'Victim', 'NAT-901238', '+1-555-2233', 'h.troy@aerotech.com', 'Grand Metropolitan Hotel #1402', 'Deceased defense contractor executive', 5),
(11, 'Julian Drake', 'Suspect', 'NAT-774411', '+1-555-4455', 'jdrake@shadowcapital.co', '200 Waterfront Luxury Lofts', 'Business rival seen leaving room 1402 on CCTV', 5),
(12, 'Officer David Cole', 'Suspect', 'BADGE-405', '+1-555-0455', 'd.cole@metropolice.gov', 'Precinct Locker #12', 'Officer under inquiry for unlogged vault access', 6),
(13, 'Jessica Huang', 'Victim', 'NAT-228192', '+1-555-8833', 'j.huang@cityuni.edu', '910 University Ave', 'Student attacked while jogging in Greenway Park', 7),
(14, 'Braden Thorne', 'Suspect', 'NAT-665123', '+1-555-9900', 'bthorne@nomail.com', 'Transient / Downtown Shelter', 'Perpetrator apprehended at scene of Greenway assault', 7);

-- 4. SEED ARRESTS
INSERT INTO `arrests` (`arrest_id`, `person_id`, `case_id`, `officer_id`, `charges`, `arrest_date`, `booking_status`, `bail_amount`, `facility_location`) VALUES
(1, 6, 3, 4, 'Possession of Schedule I Controlled Substance with Intent to Distribute; Illegal Firearm Possession', '2026-08-05 04:30:00', 'In Custody', 250000.00, 'Metro High Security Ward 2'),
(2, 8, 4, 7, 'Grand Larceny; Commercial Burglary; Evading Law Enforcement', '2026-07-28 05:15:00', 'Awaiting Trial', 75000.00, 'Central Processing Facility'),
(3, 9, 4, 7, 'Grand Larceny; Possession of Burglary Tools; Conspiracy to Commit Robbery', '2026-07-28 05:20:00', 'Released on Bail', 50000.00, 'Central Processing Facility'),
(4, 14, 7, 5, 'Attempted Robbery with Deadly Weapon; Aggravated Battery', '2026-08-14 22:00:00', 'In Custody', 100000.00, 'North Precinct Holding Cell 3');

-- 5. SEED EVIDENCE
INSERT INTO `evidence` (`evidence_id`, `case_id`, `item_name`, `description`, `evidence_type`, `storage_location`, `collected_date`, `chain_of_custody`, `status`) VALUES
(1, 1, 'Thermal Cutting Torch & Fuel Canister', 'Industrial-grade oxy-acetylene torch found abandoned near Pier 42 breach point', 'Physical', 'Vault A - Locker 102', '2026-08-02 01:10:00', 'Officer Jenkins -> Det. Mercer -> Forensics Locker', 'In Vault'),
(2, 1, 'Burned Server Hard Drive', 'Recovered from scorched security shack. Sent for digital recovery.', 'Digital', 'Cyber Forensics Lab 4', '2026-08-02 02:30:00', 'Det. Mercer -> Det. Rostova (Cyber Lab)', 'In Forensics Lab'),
(3, 2, 'Ransomware Decryption Note & USB Beacon', 'SanDisk 32GB drive containing payload script "ShadowLock_v3.bin"', 'Digital', 'Cyber Forensics Lab 2', '2026-08-03 17:30:00', 'Det. Rostova -> Lead Analyst Chen', 'In Forensics Lab'),
(4, 3, 'Seized Narcotics Package (2.4 kg)', 'Heat-sealed brick marked with scorpion emblem tested positive for synthetic opioids', 'Narcotics', 'Narcotics Secure Vault - Safe 09', '2026-08-05 05:00:00', 'Sgt. Cole -> Property Clerk Adams', 'In Vault'),
(5, 3, 'Glock 19 9mm Pistol (Obliterated Serial)', 'Loaded handgun with extended 33-round magazine recovered from suspect waist', 'Ballistics', 'Ballistics Locker B-14', '2026-08-05 05:15:00', 'Sgt. Cole -> Ballistics Unit', 'In Vault'),
(6, 4, 'Stolen Diamond Necklaces (Qty: 18)', 'Total appraised value $420,000 recovered from trunk of getaway sedan', 'Physical', 'High-Value Vault - Safe 01', '2026-07-28 06:00:00', 'Det. Mercer -> Property Clerk Adams', 'In Vault'),
(7, 5, 'Hotel Keycard Access Log & Fingerprint Swabs', 'Digital audit log showing room 1402 unlock times; 4 latent prints lifted from door handle', 'Documentary', 'Forensics Unit Desk 03', '2026-08-11 02:00:00', 'Det. Brody -> Det. Bennett', 'In Forensics Lab'),
(8, 7, 'Tactical Folding Knife (4-inch blade)', 'Used during Greenway Park robbery attempt. Blood traces on hilt matched suspect.', 'Physical', 'Vault C - Locker 44', '2026-08-14 22:30:00', 'Officer Jenkins -> Property Desk', 'Presented in Court');

-- 6. SEED COMPLAINTS (INTERNAL AFFAIRS)
INSERT INTO `complaints` (`complaint_id`, `complaint_number`, `officer_id`, `complainant_name`, `complainant_contact`, `incident_date`, `filed_date`, `allegation_type`, `severity`, `description`, `status`, `investigator_notes`, `disciplinary_action`) VALUES
(1, 'IA-2026-0041', 4, 'Sergeant Rebecca Diaz (Audit Officer)', '+1-555-0104', '2026-08-11', '2026-08-12', 'Procedural Violation', 'Critical', 'Unauthorized access to Narcotics Vault safe 09 during non-operational hours; discrepancy in seized cash envelope.', 'Under Investigation', 'Security badge log shows Sgt. Cole accessed vault at 03:41 AM without co-signer.', 'Pending Hearing - Suspended from Active Duty'),
(2, 'IA-2026-0038', 5, 'Citizen Gregory Lawson', '+1-555-6622', '2026-07-15', '2026-07-16', 'Unlawful Search', 'Low', 'Complainant claimed vehicle trunk was searched without probable cause during traffic checkpoint.', 'Exonerated (Cleared)', 'Body camera footage reviewed: driver gave verbal consent on video tape.', 'None - Cleared'),
(3, 'IA-2026-0029', 8, 'Citizen Aaron Miller', '+1-555-7733', '2026-06-20', '2026-06-22', 'Excessive Force', 'Medium', 'Complainant alleged rough handling during detention outside nightlife district club.', 'Unfounded / Dismissed', 'Surveillance video revealed complainant actively resisted and attempted to strike arresting officer.', 'None - Dismissed'),
(4, 'IA-2026-0044', 10, 'Driver Karen Walsh', '+1-555-9944', '2026-08-08', '2026-08-09', 'Dereliction of Duty', 'Low', 'Allegation of aggressive tone during speeding citation on highway 101.', 'Pending Review', 'Awaiting supervisor dashcam audio review.', NULL);
