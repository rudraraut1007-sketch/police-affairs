/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        brand: {
          50: '#fffbeb',
          100: '#fef3c7',
          200: '#fde68a',
          300: '#fcd34d',
          400: '#f5b838', // Rigardi signature golden amber yellow
          500: '#e5a93c',
          600: '#d49226',
          700: '#b37318',
          800: '#8a5412',
          900: '#5e370b',
          950: '#331c04',
        },
        slate: {
          750: '#273446',
          800: '#1f2a39',
          850: '#18222e',
          900: '#131b25',
          950: '#0e141c',
        }
      },
      fontFamily: {
        sans: ['Inter', 'Plus Jakarta Sans', 'system-ui', 'sans-serif'],
        mono: ['"JetBrains Mono"', '"Fira Code"', 'monospace']
      }
    },
  },
  plugins: [],
}
