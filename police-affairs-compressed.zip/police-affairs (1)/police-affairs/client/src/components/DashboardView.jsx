import React from 'react';
import { 
  FolderOpen, 
  Shield, 
  Lock, 
  Archive, 
  AlertCircle, 
  Users, 
  ChevronRight, 
  CheckCircle2, 
  TrendingUp,
  MapPin,
  Clock
} from 'lucide-react';

export function DashboardView({ stats, onSelectCase, onSelectTab, onOpenNewCase }) {
  const summary = stats?.summary || {};
  const recentCases = stats?.recentCases || [];
  const recentArrests = stats?.recentArrests || [];
  const casesByType = stats?.casesByType || [];

  const kpis = [
    {
      label: 'Active Cases',
      value: summary.activeCases || 6,
      total: `${summary.totalCases || 8} total recorded`,
      icon: FolderOpen,
      gradient: 'from-brand-400 to-amber-600',
      badge: `${summary.clearanceRate || 75}% Solved`,
      badgeColor: 'text-brand-300 bg-brand-500/10 border-brand-500/30'
    },
    {
      label: 'Active Officers',
      value: summary.activeOfficers || 10,
      total: `${summary.totalOfficers || 10} sworn personnel`,
      icon: Shield,
      gradient: 'from-amber-500 to-brand-600',
      badge: 'All Units Ready',
      badgeColor: 'text-brand-300 bg-brand-500/10 border-brand-500/30'
    },
    {
      label: 'In Custody Bookings',
      value: summary.inCustodyArrests || 3,
      total: `${summary.totalArrests || 4} total arrests`,
      icon: Lock,
      gradient: 'from-amber-600 to-brand-700',
      badge: 'Holding Ward 2',
      badgeColor: 'text-amber-400 bg-amber-500/10 border-amber-500/20'
    },
    {
      label: 'Vault Evidence Items',
      value: summary.totalEvidence || 8,
      total: '100% Chain Secured',
      icon: Archive,
      gradient: 'from-brand-500 to-amber-600',
      badge: 'Forensics Verified',
      badgeColor: 'text-brand-400 bg-brand-500/10 border-brand-500/20'
    },
  ];

  return (
    <div className="space-y-6 pb-10 max-w-7xl mx-auto">
      {/* Rigardi CCTV Style Hero Section */}
      <div className="glass-card rounded-2xl p-6 sm:p-7 relative overflow-hidden border border-slate-800/80 bg-slate-900/90">
        <div className="relative z-10 max-w-3xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-brand-500/10 border border-brand-500/30 text-brand-400 text-[11px] font-mono font-bold mb-3 tracking-wide">
            <span className="w-2 h-2 rounded-full bg-brand-400" />
            <span>RIGARDI CCTV & SECURITY COMMAND MATRIX</span>
          </div>
          <h1 className="text-2xl sm:text-3xl lg:text-4xl font-black tracking-tight">
            <span className="text-brand-400">POLICE AFFAIRS</span>{' '}
            <span className="text-white">& ACCESS CONTROL</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-2 leading-relaxed max-w-2xl">
            Integrated surveillance and law enforcement DBMS. Real-time active incident logs, forensic locker chain-of-custody, officer deployments, and internal integrity review.
          </p>
          <div className="flex items-center gap-3 mt-5">
            <button
              onClick={onOpenNewCase}
              className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-brand-400 via-brand-500 to-amber-500 hover:from-brand-300 hover:to-brand-400 text-slate-950 font-bold text-xs shadow-md shadow-black/20 hover:shadow-black/30 border border-brand-300/40 transition-all active:scale-95 flex items-center gap-2"
            >
              <span>Log Incident File</span>
              <ChevronRight className="w-3.5 h-3.5 stroke-[3]" />
            </button>
            <button
              onClick={() => onSelectTab('cases')}
              className="px-4 py-2.5 rounded-xl bg-slate-850 hover:bg-slate-800 text-slate-200 hover:text-white border border-slate-700/60 hover:border-slate-600 text-xs font-semibold transition-all"
            >
              Browse Active Dossiers
            </button>
          </div>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {kpis.map((kpi, idx) => {
          const Icon = kpi.icon;
          return (
            <div
              key={idx}
              className="glass-card glass-card-hover rounded-2xl p-5 flex flex-col justify-between"
            >
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">{kpi.label}</p>
                  <p className="text-3xl font-extrabold text-white mt-1 tracking-tight">{kpi.value}</p>
                </div>
                <div className={`p-3 rounded-xl bg-gradient-to-tr ${kpi.gradient} text-white shadow-md`}>
                  <Icon className="w-5 h-5" />
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between">
                <span className="text-xs text-slate-400">{kpi.total}</span>
                <span className={`text-[11px] font-bold px-2 py-0.5 rounded-full border ${kpi.badgeColor}`}>
                  {kpi.badge}
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Main Grid: Cases Table & Crime Categories */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Recent Incidents */}
        <div className="lg:col-span-2 glass-card rounded-2xl p-6 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-5">
              <div>
                <h3 className="text-base font-bold text-white tracking-tight">Recent Incidents & Case Feed</h3>
                <p className="text-xs text-slate-400">Live operational log across precincts</p>
              </div>
              <button
                onClick={() => onSelectTab('cases')}
                className="text-xs font-semibold text-brand-400 hover:text-brand-300 flex items-center gap-1 transition-colors"
              >
                View all cases <ChevronRight className="w-4 h-4" />
              </button>
            </div>

            <div className="divide-y divide-slate-800">
              {recentCases.map((c) => (
                <div
                  key={c.case_id}
                  onClick={() => onSelectCase(c)}
                  className="py-3.5 flex items-center justify-between gap-4 hover:bg-slate-800/40 px-2 rounded-xl transition-colors cursor-pointer group"
                >
                  <div className="space-y-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-mono font-bold text-brand-400">
                        {c.case_number}
                      </span>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                        c.priority === 'Critical' ? 'text-rose-400 bg-rose-500/10 border-rose-500/20' :
                        c.priority === 'High' ? 'text-amber-400 bg-amber-500/10 border-amber-500/20' :
                        'text-sky-400 bg-sky-500/10 border-sky-500/20'
                      }`}>
                        {c.priority}
                      </span>
                      <span className="text-xs text-slate-400">• {c.status}</span>
                    </div>

                    <h4 className="text-sm font-semibold text-slate-200 group-hover:text-white truncate">
                      {c.title}
                    </h4>

                    <div className="flex items-center gap-4 text-xs text-slate-400">
                      <span>Lead: {c.officer_name || 'Unassigned'}</span>
                      <span>{new Date(c.incident_date).toLocaleDateString()}</span>
                    </div>
                  </div>

                  <div className="p-2 rounded-lg text-slate-400 group-hover:text-white group-hover:bg-slate-800 transition-colors">
                    <ChevronRight className="w-4 h-4" />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right 1 Col: Crime Category Breakdown & Quick Actions */}
        <div className="space-y-6">
          {/* Crime Category Progress Bars */}
          <div className="glass-card rounded-2xl p-6">
            <h3 className="text-base font-bold text-white tracking-tight mb-1">Crime Distribution</h3>
            <p className="text-xs text-slate-400 mb-4">Breakdown by statutory violation</p>

            <div className="space-y-3.5">
              {casesByType.map((item, idx) => {
                const total = summary.totalCases || 8;
                const percent = Math.round((item.count / total) * 100);
                return (
                  <div key={idx} className="space-y-1.5">
                    <div className="flex justify-between text-xs">
                      <span className="font-semibold text-slate-300">{item.type}</span>
                      <span className="text-slate-400 font-mono">{item.count} ({percent}%)</span>
                    </div>
                    <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-brand-500 via-brand-400 to-amber-300 rounded-full transition-all duration-500"
                        style={{ width: `${percent}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Operational Quick Actions */}
          <div className="glass-card rounded-2xl p-6">
            <h3 className="text-base font-bold text-white tracking-tight mb-2">Quick Navigation</h3>
            <div className="space-y-2 pt-1">
              <button
                onClick={() => onSelectTab('complaints')}
                className="w-full py-2.5 px-4 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/20 text-xs font-semibold flex items-center justify-between transition-colors"
              >
                <span>Internal Affairs Inquiries</span>
                <ChevronRight className="w-4 h-4" />
              </button>
              <button
                onClick={() => onSelectTab('evidence')}
                className="w-full py-2.5 px-4 rounded-xl bg-slate-800/80 hover:bg-slate-750 text-slate-300 border border-slate-700/60 text-xs font-semibold flex items-center justify-between transition-colors"
              >
                <span>Evidence Vault Custody</span>
                <ChevronRight className="w-4 h-4" />
              </button>
              <button
                onClick={() => onSelectTab('arrests')}
                className="w-full py-2.5 px-4 rounded-xl bg-slate-800/80 hover:bg-slate-750 text-slate-300 border border-slate-700/60 text-xs font-semibold flex items-center justify-between transition-colors"
              >
                <span>Arrests & Custody Log</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
