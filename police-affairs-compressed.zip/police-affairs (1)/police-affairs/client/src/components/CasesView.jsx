import React, { useState } from 'react';
import { 
  FolderOpen, 
  Plus, 
  Search, 
  MapPin, 
  Calendar, 
  User, 
  Edit, 
  Trash2, 
  Archive, 
  Lock, 
  Users,
  ChevronRight
} from 'lucide-react';

export function CasesView({ cases, onSelectCase, onEditCase, onDeleteCase, onAddNewCase }) {
  const [filterPriority, setFilterPriority] = useState('');
  const [filterStatus, setFilterStatus] = useState('');
  const [filterType, setFilterType] = useState('');
  const [searchTerm, setSearchTerm] = useState('');

  const filteredCases = cases.filter((c) => {
    const matchesPriority = !filterPriority || c.priority === filterPriority;
    const matchesStatus = !filterStatus || c.status === filterStatus;
    const matchesType = !filterType || c.type === filterType;
    const matchesSearch = !searchTerm ||
      c.case_number.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (c.assigned_officer_name && c.assigned_officer_name.toLowerCase().includes(searchTerm.toLowerCase()));
    return matchesPriority && matchesStatus && matchesType && matchesSearch;
  });

  const crimeTypes = [...new Set(cases.map(c => c.type))];

  return (
    <div className="space-y-6 pb-10 max-w-7xl mx-auto">
      {/* Header & Controls Bar */}
      <div className="glass-card rounded-2xl p-5 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-white tracking-tight">Active Cases & Incident Registry</h2>
          <p className="text-xs text-slate-400">Total {cases.length} reported investigations and incident files</p>
        </div>

        <div className="flex items-center flex-wrap gap-3 w-full lg:w-auto">
          {/* Search */}
          <div className="relative flex-1 sm:w-56">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search case #, title..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-slate-800/80 border border-slate-700/60 focus:border-brand-500 text-slate-100 text-xs pl-9 pr-3 py-2 rounded-xl placeholder-slate-400 focus:outline-none"
            />
          </div>

          {/* Crime Type Filter */}
          <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
            className="bg-slate-800/80 border border-slate-700/60 text-slate-200 text-xs px-3 py-2 rounded-xl focus:outline-none"
          >
            <option value="">All Categories</option>
            {crimeTypes.map(t => <option key={t} value={t}>{t}</option>)}
          </select>

          {/* Priority Filter */}
          <select
            value={filterPriority}
            onChange={(e) => setFilterPriority(e.target.value)}
            className="bg-slate-800/80 border border-slate-700/60 text-slate-200 text-xs px-3 py-2 rounded-xl focus:outline-none"
          >
            <option value="">All Priorities</option>
            <option value="Critical">Critical</option>
            <option value="High">High</option>
            <option value="Medium">Medium</option>
            <option value="Low">Low</option>
          </select>

          {/* Status Filter */}
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="bg-slate-800/80 border border-slate-700/60 text-slate-200 text-xs px-3 py-2 rounded-xl focus:outline-none"
          >
            <option value="">All Statuses</option>
            <option value="Open">Open</option>
            <option value="Under Investigation">Under Investigation</option>
            <option value="Pending Review">Pending Review</option>
            <option value="Closed - Solved">Closed - Solved</option>
            <option value="Closed - Unsolved">Closed - Unsolved</option>
          </select>

          {/* Open Case Button */}
          <button
            onClick={onAddNewCase}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-brand-400 via-brand-500 to-amber-500 hover:from-brand-300 hover:to-brand-400 text-slate-950 font-bold text-xs shadow-md shadow-black/20 hover:shadow-black/30 border border-brand-300/40 transition-all active:scale-95"
          >
            <Plus className="w-4 h-4 stroke-[3]" />
            <span>Open Incident</span>
          </button>
        </div>
      </div>

      {/* Cases Cards List */}
      <div className="space-y-4">
        {filteredCases.map((c) => (
          <div
            key={c.case_id}
            onClick={() => onSelectCase(c)}
            className="glass-card glass-card-hover rounded-2xl p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-5 cursor-pointer group"
          >
            {/* Case Details */}
            <div className="space-y-2 flex-1 min-w-0">
              <div className="flex items-center flex-wrap gap-2">
                <span className="font-mono font-bold text-xs text-brand-400 bg-brand-500/10 px-2.5 py-0.5 rounded-lg border border-brand-500/20">
                  {c.case_number}
                </span>

                <span className="text-xs font-semibold px-2.5 py-0.5 rounded-lg bg-slate-800 text-slate-300">
                  {c.type}
                </span>

                <span className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full border ${
                  c.priority === 'Critical' ? 'text-rose-400 bg-rose-500/10 border-rose-500/20' :
                  c.priority === 'High' ? 'text-amber-400 bg-amber-500/10 border-amber-500/20' :
                  'text-sky-400 bg-sky-500/10 border-sky-500/20'
                }`}>
                  {c.priority} Priority
                </span>

                <span className={`text-xs font-semibold ${
                  c.status.includes('Closed') ? 'text-emerald-400' : 'text-slate-400'
                }`}>
                  • {c.status}
                </span>
              </div>

              <h3 className="text-base font-bold text-white group-hover:text-brand-300 transition-colors">
                {c.title}
              </h3>

              <div className="flex items-center flex-wrap gap-4 text-xs text-slate-400">
                <div className="flex items-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-slate-400" />
                  <span>{c.location}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-slate-400" />
                  <span>{new Date(c.incident_date).toLocaleDateString()}</span>
                </div>
                {c.assigned_officer_name && (
                  <div className="flex items-center gap-1.5 text-slate-300">
                    <User className="w-3.5 h-3.5 text-brand-400" />
                    <span>Lead: {c.assigned_officer_name}</span>
                  </div>
                )}
              </div>
            </div>

            {/* Relational Indicators (Persons, Evidence, Arrests) */}
            <div className="flex items-center gap-3 shrink-0">
              <div className="px-3.5 py-2 rounded-xl bg-slate-850 border border-slate-800 text-center">
                <span className="text-[10px] text-slate-400 block font-semibold">PERSONS</span>
                <span className="text-sm font-bold text-white font-mono">{c.persons_count || 0}</span>
              </div>

              <div className="px-3.5 py-2 rounded-xl bg-slate-850 border border-slate-800 text-center">
                <span className="text-[10px] text-slate-400 block font-semibold">EVIDENCE</span>
                <span className="text-sm font-bold text-purple-400 font-mono">{c.evidence_count || 0}</span>
              </div>

              <div className="px-3.5 py-2 rounded-xl bg-slate-850 border border-slate-800 text-center">
                <span className="text-[10px] text-slate-400 block font-semibold">ARRESTS</span>
                <span className="text-sm font-bold text-emerald-400 font-mono">{c.arrests_count || 0}</span>
              </div>

              {/* Actions */}
              <div className="flex items-center gap-1 pl-2 border-l border-slate-800">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onEditCase(c);
                  }}
                  className="p-2 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
                >
                  <Edit className="w-4 h-4" />
                </button>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    if (confirm(`Delete case ${c.case_number}?`)) {
                      onDeleteCase(c.case_id);
                    }
                  }}
                  className="p-2 rounded-lg hover:bg-rose-500/10 text-slate-400 hover:text-rose-400 transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
