import React from 'react';
import { 
  LayoutDashboard, 
  Shield, 
  FolderOpen, 
  Users, 
  Lock, 
  Archive, 
  AlertCircle, 
  ChevronRight,
  Database
} from 'lucide-react';

export function Sidebar({ activeTab, onSelectTab, counts = {} }) {
  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'cases', label: 'Cases & Incidents', icon: FolderOpen, count: counts.cases },
    { id: 'officers', label: 'Officers Roster', icon: Shield, count: counts.officers },
    { id: 'persons', label: 'Persons of Interest', icon: Users, count: counts.persons },
    { id: 'arrests', label: 'Arrests & Bookings', icon: Lock, count: counts.arrests },
    { id: 'evidence', label: 'Evidence Locker', icon: Archive, count: counts.evidence },
    { id: 'complaints', label: 'Internal Affairs', icon: AlertCircle, count: counts.complaints, alert: true },
  ];

  return (
    <aside className="w-64 bg-slate-900/90 backdrop-blur-xl border-r border-slate-800 flex flex-col justify-between shrink-0 select-none">
      <div>
        {/* Brand Header */}
        <div className="h-16 px-5 flex items-center gap-3 border-b border-slate-800/80">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-brand-400 via-brand-500 to-amber-600 flex items-center justify-center text-slate-950 font-black text-sm shadow-md shadow-black/30 border border-brand-300/40">
            PA
          </div>
          <div>
            <h1 className="font-bold text-sm text-white tracking-tight">Police Affairs</h1>
            <p className="text-[10px] text-brand-400 font-bold tracking-wider uppercase">CCTV & SECURITY</p>
          </div>
        </div>

        {/* Navigation Links */}
        <nav className="p-3 space-y-1">
          <div className="px-3 py-2 text-[11px] font-semibold text-slate-400 tracking-wider uppercase">
            Operations
          </div>

          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onSelectTab(item.id)}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all group ${
                  isActive
                    ? 'bg-gradient-to-r from-brand-400 to-brand-500 text-slate-950 font-bold shadow-sm shadow-black/20'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Icon className={`w-4 h-4 transition-colors ${
                    isActive ? 'text-slate-950' : 'text-slate-400 group-hover:text-brand-400'
                  }`} />
                  <span>{item.label}</span>
                </div>

                {item.count !== undefined && item.count !== null && (
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                    isActive 
                      ? 'bg-slate-950/20 text-slate-950' 
                      : item.alert
                        ? 'bg-amber-500/10 text-brand-400 border border-brand-500/30'
                        : 'bg-slate-800 text-slate-400'
                  }`}>
                    {item.count}
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Database Connection Footer */}
      <div className="p-4 border-t border-slate-800/80">
        <div className="flex items-center gap-3 p-2.5 rounded-xl bg-slate-850/80 border border-slate-800">
          <div className="w-2.5 h-2.5 rounded-full bg-brand-400" />
          <div className="flex-1 min-w-0">
            <p className="text-xs font-semibold text-slate-200 truncate">SQLite Database</p>
            <p className="text-[10px] text-brand-400 font-mono truncate">CCTV FEED ACTIVE</p>
          </div>
          <Database className="w-4 h-4 text-brand-400" />
        </div>
      </div>
    </aside>
  );
}
