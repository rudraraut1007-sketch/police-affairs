import React from 'react';
import { Plus, Download, Search, RefreshCw, Radio, Shield, Video } from 'lucide-react';
import { api } from '../services/api';

export function TopNav({ activeTab, onOpenNewModal, onRefresh, globalSearch, setGlobalSearch }) {
  const getTabTitle = () => {
    switch (activeTab) {
      case 'dashboard': return 'Command Dashboard';
      case 'cases': return 'Cases & Incidents';
      case 'officers': return 'Police Officers';
      case 'persons': return 'Involved Persons';
      case 'arrests': return 'Arrests & Custody';
      case 'evidence': return 'Evidence Vault';
      case 'complaints': return 'Internal Affairs Investigations';
      default: return 'Police Affairs';
    }
  };

  return (
    <header className="h-16 px-6 bg-slate-900/80 backdrop-blur-md border-b border-slate-800/80 flex items-center justify-between gap-4 shrink-0 select-none">
      {/* Title & Surveillance Badge */}
      <div className="flex items-center gap-3">
        <h2 className="text-base font-bold text-white tracking-tight">{getTabTitle()}</h2>
        <span className="hidden md:inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-brand-500/10 text-brand-400 border border-brand-500/30">
          <span className="w-1.5 h-1.5 rounded-full bg-brand-400"></span>
          24/7 CCTV ACTIVE
        </span>
      </div>

      {/* Center Dispatch Status (Rigardi inspired) */}
      <div className="hidden xl:flex items-center gap-5 text-[11px] text-slate-400 border-x border-slate-800 px-5">
        <span className="flex items-center gap-1.5">
          <Radio className="w-3.5 h-3.5 text-brand-400" />
          <span className="text-slate-300 font-medium">DISPATCH:</span> 10800-33-000
        </span>
        <span className="flex items-center gap-1.5">
          <Shield className="w-3.5 h-3.5 text-brand-400" />
          <span className="text-slate-300 font-medium">PRECINCT:</span> 21 METRO
        </span>
      </div>

      {/* Right Controls */}
      <div className="flex items-center gap-3">
        {/* Search */}
        <div className="relative w-64">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search records, badge, case..."
            value={globalSearch}
            onChange={(e) => setGlobalSearch(e.target.value)}
            className="w-full bg-slate-850 border border-slate-700/60 focus:border-brand-400 text-slate-100 text-xs pl-9 pr-3 py-2 rounded-xl placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-brand-400/20 transition-all"
          />
        </div>

        {/* Refresh */}
        <button
          onClick={onRefresh}
          title="Reload records"
          className="p-2 rounded-xl bg-slate-850 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-700/60 hover:border-brand-500/40 transition-all"
        >
          <RefreshCw className="w-4 h-4" />
        </button>

        {/* Export MySQL Dump */}
        <button
          onClick={() => api.exportMySQL()}
          title="Download complete MySQL DDL and DML scripts (.sql)"
          className="hidden sm:flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-850 hover:bg-slate-800 text-slate-200 hover:text-brand-300 border border-slate-700/60 hover:border-brand-500/40 text-xs font-semibold transition-all"
        >
          <Download className="w-4 h-4 text-brand-400" />
          <span>Export SQL</span>
        </button>

        {/* + New Action */}
        <button
          onClick={onOpenNewModal}
          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-brand-400 via-brand-500 to-amber-500 hover:from-brand-300 hover:to-brand-400 text-slate-950 font-bold text-xs shadow-md shadow-black/20 hover:shadow-black/30 border border-brand-300/40 transition-all active:scale-95"
        >
          <Plus className="w-4 h-4 stroke-[3]" />
          <span>New Entry</span>
        </button>
      </div>
    </header>
  );
}
