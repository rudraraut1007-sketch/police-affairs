import React, { useState } from 'react';
import { Archive, Plus, Search, Calendar, GitCommit, Edit, Trash2 } from 'lucide-react';

export function EvidenceView({ evidence, onSelectEvidence, onEditEvidence, onDeleteEvidence, onAddNewEvidence }) {
  const [filterType, setFilterType] = useState('');
  const [filterStatus, setFilterStatus] = useState('');
  const [searchTerm, setSearchTerm] = useState('');

  const filteredEvidence = evidence.filter((e) => {
    const matchesType = !filterType || e.evidence_type === filterType;
    const matchesStatus = !filterStatus || e.status === filterStatus;
    const matchesSearch = !searchTerm ||
      e.item_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      e.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      e.storage_location.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (e.case_number && e.case_number.toLowerCase().includes(searchTerm.toLowerCase()));
    return matchesType && matchesStatus && matchesSearch;
  });

  const evidenceTypes = [...new Set(evidence.map(e => e.evidence_type))];

  return (
    <div className="space-y-6 pb-10 max-w-7xl mx-auto">
      {/* Header & Controls Bar */}
      <div className="glass-card rounded-2xl p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-white tracking-tight">Evidence Vault & Chain of Custody</h2>
          <p className="text-xs text-slate-400">Total {evidence.length} secured physical and forensic artifacts</p>
        </div>

        <div className="flex items-center flex-wrap gap-3 w-full md:w-auto">
          {/* Search */}
          <div className="relative flex-1 sm:w-56">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search evidence item..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-slate-800/80 border border-slate-700/60 focus:border-brand-500 text-slate-100 text-xs pl-9 pr-3 py-2 rounded-xl placeholder-slate-400 focus:outline-none"
            />
          </div>

          {/* Type Filter */}
          <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
            className="bg-slate-800/80 border border-slate-700/60 text-slate-200 text-xs px-3 py-2 rounded-xl focus:outline-none"
          >
            <option value="">All Categories</option>
            {evidenceTypes.map(t => <option key={t} value={t}>{t}</option>)}
          </select>

          {/* Custody Status Filter */}
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="bg-slate-800/80 border border-slate-700/60 text-slate-200 text-xs px-3 py-2 rounded-xl focus:outline-none"
          >
            <option value="">All Statuses</option>
            <option value="In Vault">In Vault</option>
            <option value="In Forensics Lab">In Forensics Lab</option>
            <option value="Presented in Court">Presented in Court</option>
            <option value="Disposed / Returned">Disposed / Returned</option>
          </select>

          {/* Add Evidence */}
          <button
            onClick={onAddNewEvidence}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-brand-400 via-brand-500 to-amber-500 hover:from-brand-300 hover:to-brand-400 text-slate-950 font-bold text-xs shadow-md shadow-black/20 hover:shadow-black/30 border border-brand-300/40 transition-all active:scale-95"
          >
            <Plus className="w-4 h-4 stroke-[3]" />
            <span>Vault Log</span>
          </button>
        </div>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredEvidence.map((e) => (
          <div
            key={e.evidence_id}
            onClick={() => onSelectEvidence(e)}
            className="glass-card glass-card-hover rounded-2xl p-5 flex flex-col justify-between cursor-pointer"
          >
            <div>
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-mono font-bold text-purple-400 bg-purple-500/10 px-2.5 py-0.5 rounded-lg border border-purple-500/20">
                  VAULT #{e.evidence_id}
                </span>

                <span className={`text-[10px] font-bold px-2.5 py-1 rounded-full border ${
                  e.status === 'In Vault' ? 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20' :
                  e.status === 'In Forensics Lab' ? 'text-sky-400 bg-sky-500/10 border-sky-500/20' :
                  'text-amber-400 bg-amber-500/10 border-amber-500/20'
                }`}>
                  {e.status}
                </span>
              </div>

              <h3 className="text-sm font-bold text-white tracking-tight">
                {e.item_name}
              </h3>

              <p className="text-xs text-slate-400 mt-2 line-clamp-2">
                {e.description}
              </p>

              {/* Storage Locker & Category */}
              <div className="grid grid-cols-2 gap-3 mt-4 text-xs">
                <div className="p-2.5 rounded-xl bg-slate-850 border border-slate-800">
                  <span className="text-[10px] text-slate-400 uppercase block font-semibold">Storage Location</span>
                  <span className="font-semibold text-slate-200 truncate block mt-0.5">
                    {e.storage_location}
                  </span>
                </div>

                <div className="p-2.5 rounded-xl bg-slate-850 border border-slate-800">
                  <span className="text-[10px] text-slate-400 uppercase block font-semibold">Category</span>
                  <span className="font-semibold text-purple-300 truncate block mt-0.5">
                    {e.evidence_type}
                  </span>
                </div>
              </div>

              {/* Chain of custody */}
              {e.chain_of_custody && (
                <div className="mt-3 p-2.5 rounded-xl bg-slate-850 border border-slate-800 text-xs">
                  <div className="text-[10px] text-slate-400 uppercase font-semibold flex items-center gap-1 mb-1">
                    <GitCommit className="w-3.5 h-3.5 text-brand-400" /> Chain of Custody
                  </div>
                  <p className="text-slate-300 truncate font-mono text-[11px]">
                    {e.chain_of_custody}
                  </p>
                </div>
              )}

              <div className="mt-4 flex items-center gap-2 text-xs text-slate-400">
                <Calendar className="w-3.5 h-3.5 text-slate-400" />
                <span>Collected: {new Date(e.collected_date).toLocaleDateString()}</span>
              </div>
            </div>

            {/* Bottom Actions */}
            <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between">
              <span className="text-xs font-mono text-slate-400">Case: {e.case_number}</span>
              <div className="flex items-center gap-1">
                <button
                  onClick={(event) => {
                    event.stopPropagation();
                    onEditEvidence(e);
                  }}
                  className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
                >
                  <Edit className="w-4 h-4" />
                </button>
                <button
                  onClick={(event) => {
                    event.stopPropagation();
                    if (confirm(`Delete evidence item #${e.evidence_id}?`)) {
                      onDeleteEvidence(e.evidence_id);
                    }
                  }}
                  className="p-1.5 rounded-lg hover:bg-rose-500/10 text-slate-400 hover:text-rose-400 transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
