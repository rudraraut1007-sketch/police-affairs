import React, { useState } from 'react';
import { AlertCircle, Plus, Search, Calendar, User, Edit, Trash2, ShieldAlert } from 'lucide-react';

export function ComplaintsView({ complaints, onSelectComplaint, onEditComplaint, onDeleteComplaint, onAddNewComplaint }) {
  const [filterSeverity, setFilterSeverity] = useState('');
  const [filterStatus, setFilterStatus] = useState('');
  const [searchTerm, setSearchTerm] = useState('');

  const filteredComplaints = complaints.filter((cp) => {
    const matchesSeverity = !filterSeverity || cp.severity === filterSeverity;
    const matchesStatus = !filterStatus || cp.status === filterStatus;
    const matchesSearch = !searchTerm ||
      cp.complaint_number.toLowerCase().includes(searchTerm.toLowerCase()) ||
      cp.complainant_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      cp.allegation_type.toLowerCase().includes(searchTerm.toLowerCase()) ||
      cp.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (cp.officer_name && cp.officer_name.toLowerCase().includes(searchTerm.toLowerCase()));
    return matchesSeverity && matchesStatus && matchesSearch;
  });

  return (
    <div className="space-y-6 pb-10 max-w-7xl mx-auto">
      {/* Header & Controls Bar */}
      <div className="glass-card rounded-2xl p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-white tracking-tight">Internal Affairs & Integrity Oversight</h2>
          <p className="text-xs text-slate-400">Total {complaints.length} misconduct investigations and citizen grievances</p>
        </div>

        <div className="flex items-center flex-wrap gap-3 w-full md:w-auto">
          {/* Search */}
          <div className="relative flex-1 sm:w-56">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search IA file..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-slate-800/80 border border-slate-700/60 focus:border-brand-500 text-slate-100 text-xs pl-9 pr-3 py-2 rounded-xl placeholder-slate-400 focus:outline-none"
            />
          </div>

          {/* Severity Filter */}
          <select
            value={filterSeverity}
            onChange={(e) => setFilterSeverity(e.target.value)}
            className="bg-slate-800/80 border border-slate-700/60 text-slate-200 text-xs px-3 py-2 rounded-xl focus:outline-none"
          >
            <option value="">All Severities</option>
            <option value="Critical">Critical</option>
            <option value="High">High</option>
            <option value="Medium">Medium</option>
            <option value="Low">Low</option>
          </select>

          {/* Status Filter */}
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="bg-slate-800/80 border border-slate-700/60 text-slate-200 text-xs px-3 py-2 rounded-xl focus:outline-none"
          >
            <option value="">All Statuses</option>
            <option value="Under Investigation">Under Investigation</option>
            <option value="Pending Review">Pending Review</option>
            <option value="Sustained (Guilty)">Sustained (Guilty)</option>
            <option value="Exonerated (Cleared)">Exonerated (Cleared)</option>
            <option value="Unfounded / Dismissed">Unfounded / Dismissed</option>
          </select>

          {/* New Complaint */}
          <button
            onClick={onAddNewComplaint}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-brand-400 via-brand-500 to-amber-500 hover:from-brand-300 hover:to-brand-400 text-slate-950 font-bold text-xs shadow-md shadow-black/20 hover:shadow-black/30 border border-brand-300/40 transition-all active:scale-95"
          >
            <Plus className="w-4 h-4 stroke-[3]" />
            <span>Lodge Grievance</span>
          </button>
        </div>
      </div>

      {/* Grid */}
      <div className="space-y-4">
        {filteredComplaints.map((cp) => (
          <div
            key={cp.complaint_id}
            onClick={() => onSelectComplaint(cp)}
            className="glass-card glass-card-hover rounded-2xl p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-5 cursor-pointer group"
          >
            <div className="space-y-2 flex-1 min-w-0">
              <div className="flex items-center flex-wrap gap-2">
                <span className="font-mono font-bold text-xs text-amber-400 bg-amber-500/10 px-2.5 py-0.5 rounded-lg border border-amber-500/20">
                  {cp.complaint_number}
                </span>

                <span className="text-xs font-semibold px-2.5 py-0.5 rounded-lg bg-slate-800 text-slate-200">
                  {cp.allegation_type}
                </span>

                <span className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full border ${
                  cp.severity === 'Critical' ? 'text-rose-400 bg-rose-500/10 border-rose-500/20' :
                  cp.severity === 'High' ? 'text-amber-400 bg-amber-500/10 border-amber-500/20' :
                  'text-sky-400 bg-sky-500/10 border-sky-500/20'
                }`}>
                  {cp.severity} Severity
                </span>

                <span className={`text-xs font-semibold ${
                  cp.status.includes('Sustained') ? 'text-rose-400 font-bold' :
                  cp.status.includes('Exonerated') ? 'text-emerald-400' :
                  'text-amber-400'
                }`}>
                  • {cp.status}
                </span>
              </div>

              <p className="text-xs text-slate-300 line-clamp-2 leading-relaxed">
                {cp.description}
              </p>

              <div className="flex items-center flex-wrap gap-4 text-xs text-slate-400 pt-1">
                <div className="flex items-center gap-1.5 text-slate-200 font-medium">
                  <User className="w-3.5 h-3.5 text-brand-400" />
                  <span>Subject: {cp.officer_name} ({cp.officer_badge})</span>
                </div>
                <div>
                  <span>Complainant: {cp.complainant_name}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-slate-400" />
                  <span>Filed: {cp.filed_date}</span>
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="flex items-center gap-2 shrink-0 border-l border-slate-800 pl-4">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onEditComplaint(cp);
                }}
                className="p-2 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
              >
                <Edit className="w-4 h-4" />
              </button>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  if (confirm(`Remove complaint ${cp.complaint_number}?`)) {
                    onDeleteComplaint(cp.complaint_id);
                  }
                }}
                className="p-2 rounded-lg hover:bg-rose-500/10 text-slate-400 hover:text-rose-400 transition-colors"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
