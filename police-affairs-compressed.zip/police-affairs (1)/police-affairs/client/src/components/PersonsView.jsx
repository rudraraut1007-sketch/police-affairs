import React, { useState } from 'react';
import { Users, Plus, Search, Phone, MapPin, Edit, Trash2 } from 'lucide-react';

export function PersonsView({ persons, onSelectPerson, onEditPerson, onDeletePerson, onAddNewPerson }) {
  const [filterRole, setFilterRole] = useState('');
  const [searchTerm, setSearchTerm] = useState('');

  const filteredPersons = persons.filter((p) => {
    const matchesRole = !filterRole || p.role === filterRole;
    const matchesSearch = !searchTerm ||
      p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (p.national_id && p.national_id.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (p.case_number && p.case_number.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (p.notes && p.notes.toLowerCase().includes(searchTerm.toLowerCase()));
    return matchesRole && matchesSearch;
  });

  return (
    <div className="space-y-6 pb-10 max-w-7xl mx-auto">
      {/* Header & Filter Controls */}
      <div className="glass-card rounded-2xl p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-white tracking-tight">Persons of Interest & Involved Parties</h2>
          <p className="text-xs text-slate-400">Total {persons.length} recorded victims, witnesses, informants, and suspects</p>
        </div>

        <div className="flex items-center flex-wrap gap-3 w-full md:w-auto">
          {/* Search */}
          <div className="relative flex-1 sm:w-56">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search person or ID..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-slate-800/80 border border-slate-700/60 focus:border-brand-500 text-slate-100 text-xs pl-9 pr-3 py-2 rounded-xl placeholder-slate-400 focus:outline-none"
            />
          </div>

          {/* Role Filter */}
          <select
            value={filterRole}
            onChange={(e) => setFilterRole(e.target.value)}
            className="bg-slate-800/80 border border-slate-700/60 text-slate-200 text-xs px-3 py-2 rounded-xl focus:outline-none"
          >
            <option value="">All Roles</option>
            <option value="Suspect">Suspects</option>
            <option value="Victim">Victims</option>
            <option value="Witness">Witnesses</option>
            <option value="Person of Interest">Persons of Interest</option>
            <option value="Informant">Informants</option>
          </select>

          {/* Add Person */}
          <button
            onClick={onAddNewPerson}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-brand-400 via-brand-500 to-amber-500 hover:from-brand-300 hover:to-brand-400 text-slate-950 font-bold text-xs shadow-md shadow-black/20 hover:shadow-black/30 border border-brand-300/40 transition-all active:scale-95"
          >
            <Plus className="w-4 h-4 stroke-[3]" />
            <span>Link Person</span>
          </button>
        </div>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredPersons.map((p) => (
          <div
            key={p.person_id}
            onClick={() => onSelectPerson(p)}
            className="glass-card glass-card-hover rounded-2xl p-5 flex flex-col justify-between cursor-pointer"
          >
            <div>
              <div className="flex items-center justify-between mb-3">
                <span className={`text-[10px] font-bold px-2.5 py-1 rounded-full border ${
                  p.role === 'Suspect' ? 'text-rose-400 bg-rose-500/10 border-rose-500/20' :
                  p.role === 'Victim' ? 'text-sky-400 bg-sky-500/10 border-sky-500/20' :
                  p.role === 'Witness' ? 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20' :
                  'text-amber-400 bg-amber-500/10 border-amber-500/20'
                }`}>
                  {p.role}
                </span>

                <span className="text-xs font-mono text-slate-400">
                  {p.national_id || 'ID: UNRECORDED'}
                </span>
              </div>

              <h3 className="text-sm font-bold text-white tracking-tight">
                {p.name}
              </h3>

              {p.notes && (
                <p className="text-xs text-slate-400 mt-2 line-clamp-2 italic">
                  "{p.notes}"
                </p>
              )}

              {/* Linked Case Chip */}
              <div className="mt-4 p-3 rounded-xl bg-slate-850 border border-slate-800 text-xs">
                <span className="text-[10px] text-slate-400 uppercase font-semibold block">Linked Incident File</span>
                <span className="text-brand-300 font-semibold truncate block mt-0.5">
                  {p.case_number} - {p.case_title}
                </span>
              </div>

              <div className="mt-4 space-y-1.5 text-xs text-slate-400">
                {p.contact && (
                  <div className="flex items-center gap-2">
                    <Phone className="w-3.5 h-3.5 text-slate-400" />
                    <span>{p.contact}</span>
                  </div>
                )}
                {p.address && (
                  <div className="flex items-center gap-2 truncate">
                    <MapPin className="w-3.5 h-3.5 text-slate-400" />
                    <span className="truncate">{p.address}</span>
                  </div>
                )}
              </div>
            </div>

            {/* Bottom Actions */}
            <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-end gap-1">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onEditPerson(p);
                }}
                className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
              >
                <Edit className="w-4 h-4" />
              </button>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  if (confirm(`Remove person ${p.name}?`)) {
                    onDeletePerson(p.person_id);
                  }
                }}
                className="p-1.5 rounded-lg hover:bg-rose-500/10 text-slate-400 hover:text-rose-400 transition-colors"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
