import React, { useState } from 'react';
import { Lock, Plus, Search, Calendar, MapPin, Edit, Trash2 } from 'lucide-react';

export function ArrestsView({ arrests, onSelectArrest, onEditArrest, onDeleteArrest, onAddNewArrest }) {
  const [filterStatus, setFilterStatus] = useState('');
  const [searchTerm, setSearchTerm] = useState('');

  const filteredArrests = arrests.filter((a) => {
    const matchesStatus = !filterStatus || a.booking_status === filterStatus;
    const matchesSearch = !searchTerm ||
      a.person_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      a.charges.toLowerCase().includes(searchTerm.toLowerCase()) ||
      a.case_number.toLowerCase().includes(searchTerm.toLowerCase()) ||
      a.facility_location.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (a.officer_name && a.officer_name.toLowerCase().includes(searchTerm.toLowerCase()));
    return matchesStatus && matchesSearch;
  });

  return (
    <div className="space-y-6 pb-10 max-w-7xl mx-auto">
      {/* Header & Controls Bar */}
      <div className="glass-card rounded-2xl p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-white tracking-tight">Custodial Bookings & Arrests Roster</h2>
          <p className="text-xs text-slate-400">Total {arrests.length} formal criminal bookings on record</p>
        </div>

        <div className="flex items-center flex-wrap gap-3 w-full md:w-auto">
          {/* Search */}
          <div className="relative flex-1 sm:w-56">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search suspect or charge..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-slate-800/80 border border-slate-700/60 focus:border-brand-500 text-slate-100 text-xs pl-9 pr-3 py-2 rounded-xl placeholder-slate-400 focus:outline-none"
            />
          </div>

          {/* Status Filter */}
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="bg-slate-800/80 border border-slate-700/60 text-slate-200 text-xs px-3 py-2 rounded-xl focus:outline-none"
          >
            <option value="">All Statuses</option>
            <option value="In Custody">In Custody</option>
            <option value="Awaiting Trial">Awaiting Trial</option>
            <option value="Released on Bail">Released on Bail</option>
            <option value="Transferred to Prison">Transferred to Prison</option>
            <option value="Charges Dropped">Charges Dropped</option>
          </select>

          {/* New Arrest */}
          <button
            onClick={onAddNewArrest}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-brand-400 via-brand-500 to-amber-500 hover:from-brand-300 hover:to-brand-400 text-slate-950 font-bold text-xs shadow-md shadow-black/20 hover:shadow-black/30 border border-brand-300/40 transition-all active:scale-95"
          >
            <Plus className="w-4 h-4 stroke-[3]" />
            <span>Book Arrest</span>
          </button>
        </div>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {filteredArrests.map((a) => (
          <div
            key={a.arrest_id}
            onClick={() => onSelectArrest(a)}
            className="glass-card glass-card-hover rounded-2xl p-5 flex flex-col justify-between cursor-pointer"
          >
            <div>
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-mono font-bold text-amber-400 bg-amber-500/10 px-2.5 py-0.5 rounded-lg border border-amber-500/20">
                  BOOKING #{a.arrest_id}
                </span>

                <span className={`text-[10px] font-bold px-2.5 py-1 rounded-full border ${
                  a.booking_status === 'In Custody' ? 'text-rose-400 bg-rose-500/10 border-rose-500/20' :
                  a.booking_status === 'Released on Bail' ? 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20' :
                  'text-sky-400 bg-sky-500/10 border-sky-500/20'
                }`}>
                  {a.booking_status}
                </span>
              </div>

              <h3 className="text-base font-bold text-white tracking-tight">
                {a.person_name}
              </h3>

              {/* Charges */}
              <div className="mt-3 p-3 rounded-xl bg-slate-850 border border-slate-800">
                <span className="text-[10px] text-slate-400 uppercase font-semibold block mb-1">Filed Statutory Charges</span>
                <p className="text-xs text-slate-200 leading-relaxed font-mono">
                  {a.charges}
                </p>
              </div>

              {/* Details */}
              <div className="grid grid-cols-2 gap-3 mt-4 text-xs">
                <div className="p-2.5 rounded-xl bg-slate-850 border border-slate-800">
                  <span className="text-[10px] text-slate-400 uppercase block font-semibold">Bail Amount</span>
                  <span className="font-bold text-emerald-400 text-sm font-mono mt-0.5 block">
                    ${Number(a.bail_amount || 0).toLocaleString()}
                  </span>
                </div>

                <div className="p-2.5 rounded-xl bg-slate-850 border border-slate-800">
                  <span className="text-[10px] text-slate-400 uppercase block font-semibold">Arresting Officer</span>
                  <span className="font-semibold text-slate-200 truncate block mt-0.5">
                    {a.officer_name || 'Officer'}
                  </span>
                </div>
              </div>

              <div className="mt-4 space-y-1 text-xs text-slate-400">
                <div className="flex items-center gap-2">
                  <MapPin className="w-3.5 h-3.5 text-slate-400" />
                  <span>{a.facility_location}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Calendar className="w-3.5 h-3.5 text-slate-400" />
                  <span>{new Date(a.arrest_date).toLocaleString()}</span>
                </div>
              </div>
            </div>

            {/* Bottom Actions */}
            <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between">
              <span className="text-xs font-mono text-slate-400">Case: {a.case_number}</span>
              <div className="flex items-center gap-1">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onEditArrest(a);
                  }}
                  className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
                >
                  <Edit className="w-4 h-4" />
                </button>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    if (confirm(`Delete arrest record #${a.arrest_id}?`)) {
                      onDeleteArrest(a.arrest_id);
                    }
                  }}
                  className="p-1.5 rounded-lg hover:bg-rose-500/10 text-slate-400 hover:text-rose-400 transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
