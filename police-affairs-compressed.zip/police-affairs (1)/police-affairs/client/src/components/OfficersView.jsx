import React, { useState } from 'react';
import { Shield, Plus, Search, Mail, Phone, Edit, Trash2, UserCheck, AlertTriangle } from 'lucide-react';

export function OfficersView({ officers, onSelectOfficer, onEditOfficer, onDeleteOfficer, onAddNewOfficer }) {
  const [filterDept, setFilterDept] = useState('');
  const [filterStatus, setFilterStatus] = useState('');
  const [searchTerm, setSearchTerm] = useState('');

  const filteredOfficers = officers.filter((o) => {
    const matchesDept = !filterDept || o.department === filterDept;
    const matchesStatus = !filterStatus || o.status === filterStatus;
    const matchesSearch = !searchTerm || 
      o.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
      o.badge_number.toLowerCase().includes(searchTerm.toLowerCase()) ||
      o.rank.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesDept && matchesStatus && matchesSearch;
  });

  const departments = [...new Set(officers.map(o => o.department))];

  // Helper for initials
  const getInitials = (name) => {
    return name
      .replace(/^(Captain|Detective|Sergeant|Officer|Lieutenant|Senior Detective)\s+/i, '')
      .split(' ')
      .map(n => n[0])
      .join('')
      .slice(0, 2)
      .toUpperCase();
  };

  return (
    <div className="space-y-6 pb-10 max-w-7xl mx-auto">
      {/* Header & Controls Bar */}
      <div className="glass-card rounded-2xl p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-white tracking-tight">Police Officers Directory</h2>
          <p className="text-xs text-slate-400">Total {officers.length} active and assigned law enforcement personnel</p>
        </div>

        <div className="flex items-center flex-wrap gap-3 w-full md:w-auto">
          {/* Search */}
          <div className="relative flex-1 sm:w-56">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search officer or badge..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-slate-800/80 border border-slate-700/60 focus:border-brand-500 text-slate-100 text-xs pl-9 pr-3 py-2 rounded-xl placeholder-slate-400 focus:outline-none"
            />
          </div>

          {/* Department Filter */}
          <select
            value={filterDept}
            onChange={(e) => setFilterDept(e.target.value)}
            className="bg-slate-800/80 border border-slate-700/60 text-slate-200 text-xs px-3 py-2 rounded-xl focus:outline-none"
          >
            <option value="">All Divisions</option>
            {departments.map(dept => <option key={dept} value={dept}>{dept}</option>)}
          </select>

          {/* Status Filter */}
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="bg-slate-800/80 border border-slate-700/60 text-slate-200 text-xs px-3 py-2 rounded-xl focus:outline-none"
          >
            <option value="">All Statuses</option>
            <option value="Active">Active</option>
            <option value="Under Investigation">Under Investigation</option>
            <option value="Suspended">Suspended</option>
            <option value="On Leave">On Leave</option>
          </select>

          {/* Add Officer Button */}
          <button
            onClick={onAddNewOfficer}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-brand-400 via-brand-500 to-amber-500 hover:from-brand-300 hover:to-brand-400 text-slate-950 font-bold text-xs shadow-md shadow-black/20 hover:shadow-black/30 border border-brand-300/40 transition-all active:scale-95"
          >
            <Plus className="w-4 h-4 stroke-[3]" />
            <span>Add Officer</span>
          </button>
        </div>
      </div>

      {/* Officers Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredOfficers.map((o) => (
          <div
            key={o.officer_id}
            onClick={() => onSelectOfficer(o)}
            className="glass-card glass-card-hover rounded-2xl p-5 flex flex-col justify-between cursor-pointer"
          >
            <div>
              {/* Top Row: Avatar & Status */}
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-brand-400 via-brand-500 to-amber-600 flex items-center justify-center text-slate-950 font-black text-sm shadow-md border border-brand-300/30">
                    {getInitials(o.name)}
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-white tracking-tight">{o.name}</h3>
                    <p className="text-xs text-brand-400 font-medium">{o.rank}</p>
                  </div>
                </div>

                <span className={`text-[10px] font-bold px-2.5 py-1 rounded-full border ${
                  o.status === 'Active' ? 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20' :
                  o.status === 'Under Investigation' ? 'text-amber-400 bg-amber-500/10 border-amber-500/20' :
                  'text-rose-400 bg-rose-500/10 border-rose-500/20'
                }`}>
                  {o.status}
                </span>
              </div>

              {/* Department & Badge */}
              <div className="space-y-2 text-xs">
                <div className="flex items-center justify-between text-slate-400">
                  <span>Badge ID</span>
                  <span className="font-mono font-bold text-slate-200">{o.badge_number}</span>
                </div>
                <div className="flex items-center justify-between text-slate-400">
                  <span>Department</span>
                  <span className="text-slate-200 font-medium">{o.department}</span>
                </div>
                <div className="flex items-center justify-between text-slate-400">
                  <span>Assigned Shift</span>
                  <span className="text-slate-300 font-medium">{o.shift} Shift</span>
                </div>
              </div>

              {/* Contacts */}
              <div className="mt-4 pt-3 border-t border-slate-800 space-y-1.5 text-xs text-slate-400">
                <div className="flex items-center gap-2 truncate">
                  <Mail className="w-3.5 h-3.5 text-slate-400" />
                  <span className="truncate">{o.email}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Phone className="w-3.5 h-3.5 text-slate-400" />
                  <span>{o.contact}</span>
                </div>
              </div>
            </div>

            {/* Bottom Row: Caseload Stats & Actions */}
            <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-4 text-xs">
                <div>
                  <span className="text-slate-400 block text-[10px]">Cases</span>
                  <span className="font-bold text-white font-mono">{o.assigned_cases_count || 0}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px]">Arrests</span>
                  <span className="font-bold text-emerald-400 font-mono">{o.arrests_made_count || 0}</span>
                </div>
                {o.complaints_count > 0 && (
                  <div>
                    <span className="text-amber-400 block text-[10px]">IA Inquiries</span>
                    <span className="font-bold text-amber-400 font-mono">{o.complaints_count}</span>
                  </div>
                )}
              </div>

              <div className="flex items-center gap-1">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onEditOfficer(o);
                  }}
                  className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
                >
                  <Edit className="w-4 h-4" />
                </button>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    if (confirm(`Remove officer record for ${o.name}?`)) {
                      onDeleteOfficer(o.officer_id);
                    }
                  }}
                  className="p-1.5 rounded-lg hover:bg-rose-500/10 text-slate-400 hover:text-rose-400 transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
