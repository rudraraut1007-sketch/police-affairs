import React, { useState, useEffect } from 'react';
import { X, Check, Shield, FolderOpen, User, Lock, Archive, AlertCircle } from 'lucide-react';

export function ModalForm({ isOpen, onClose, entityType, initialData = null, onSubmit, officersList = [], casesList = [], personsList = [] }) {
  const [formData, setFormData] = useState({});
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (initialData) {
      setFormData(initialData);
    } else {
      if (entityType === 'officers') {
        setFormData({
          badge_number: `BADGE-${Math.floor(100 + Math.random() * 900)}`,
          name: '',
          rank: 'Patrol Officer',
          department: 'Patrol & Field Ops',
          contact: '+1-555-',
          email: '',
          hire_date: new Date().toISOString().split('T')[0],
          status: 'Active',
          shift: 'Day'
        });
      } else if (entityType === 'cases') {
        setFormData({
          case_number: `CASE-2026-${Math.floor(1000 + Math.random() * 9000)}`,
          title: '',
          incident_date: new Date().toISOString().slice(0, 16),
          location: '',
          type: 'Robbery',
          priority: 'Medium',
          status: 'Open',
          description: '',
          assigned_officer_id: officersList[0]?.officer_id || ''
        });
      } else if (entityType === 'persons') {
        setFormData({
          name: '',
          role: 'Suspect',
          national_id: `NAT-${Math.floor(100000 + Math.random() * 900000)}`,
          contact: '+1-555-',
          email: '',
          address: '',
          notes: '',
          linked_case_id: casesList[0]?.case_id || ''
        });
      } else if (entityType === 'arrests') {
        setFormData({
          person_id: personsList[0]?.person_id || '',
          case_id: casesList[0]?.case_id || '',
          officer_id: officersList[0]?.officer_id || '',
          charges: '',
          arrest_date: new Date().toISOString().slice(0, 16),
          booking_status: 'In Custody',
          bail_amount: 50000,
          facility_location: 'Central Processing Facility'
        });
      } else if (entityType === 'evidence') {
        setFormData({
          case_id: casesList[0]?.case_id || '',
          item_name: '',
          description: '',
          evidence_type: 'Physical',
          storage_location: 'Vault A - Locker 101',
          collected_date: new Date().toISOString().slice(0, 16),
          chain_of_custody: 'Collected at crime scene -> Property Clerk',
          status: 'In Vault'
        });
      } else if (entityType === 'complaints') {
        setFormData({
          complaint_number: `IA-2026-${Math.floor(1000 + Math.random() * 9000)}`,
          officer_id: officersList[0]?.officer_id || '',
          complainant_name: '',
          complainant_contact: '+1-555-',
          incident_date: new Date().toISOString().split('T')[0],
          filed_date: new Date().toISOString().split('T')[0],
          allegation_type: 'Misconduct',
          severity: 'Medium',
          description: '',
          status: 'Under Investigation',
          investigator_notes: '',
          disciplinary_action: ''
        });
      }
    }
  }, [initialData, entityType, isOpen]);

  if (!isOpen) return null;

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await onSubmit(formData);
      onClose();
    } catch (err) {
      alert(`Error saving record: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  const getTitle = () => {
    const mode = initialData ? 'Edit' : 'Register New';
    switch (entityType) {
      case 'officers': return `${mode} Officer`;
      case 'cases': return `${mode} Case / Incident`;
      case 'persons': return `${mode} Person of Interest`;
      case 'arrests': return `${mode} Arrest Booking`;
      case 'evidence': return `${mode} Evidence Vault Item`;
      case 'complaints': return `${mode} Internal Affairs Grievance`;
      default: return `${mode} Record`;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl w-full max-w-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-white tracking-tight">{getTitle()}</h2>
            <p className="text-xs text-slate-400">Entity: {entityType.toUpperCase()}</p>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-4 text-xs flex-1">
          {/* OFFICERS FIELDS */}
          {entityType === 'officers' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">Badge Number *</label>
                <input
                  type="text"
                  name="badge_number"
                  required
                  value={formData.badge_number || ''}
                  onChange={handleChange}
                  className="w-full bg-slate-800/80 border border-slate-700/60 focus:border-brand-500 text-slate-100 px-3.5 py-2.5 rounded-xl font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">Full Name *</label>
                <input
                  type="text"
                  name="name"
                  required
                  placeholder="e.g. Sarah Connor"
                  value={formData.name || ''}
                  onChange={handleChange}
                  className="w-full bg-slate-800/80 border border-slate-700/60 focus:border-brand-500 text-slate-100 px-3.5 py-2.5 rounded-xl"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">Rank *</label>
                <select
                  name="rank"
                  value={formData.rank || 'Patrol Officer'}
                  onChange={handleChange}
                  className="w-full bg-slate-800/80 border border-slate-700/60 focus:border-brand-500 text-slate-100 px-3.5 py-2.5 rounded-xl"
                >
                  <option>Patrol Officer</option>
                  <option>Senior Detective</option>
                  <option>Detective</option>
                  <option>Detective First Grade</option>
                  <option>Sergeant</option>
                  <option>Lieutenant</option>
                  <option>Captain</option>
                  <option>Commander</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">Department *</label>
                <select
                  name="department"
                  value={formData.department || 'Patrol & Field Ops'}
                  onChange={handleChange}
                  className="w-full bg-slate-800/80 border border-slate-700/60 focus:border-brand-500 text-slate-100 px-3.5 py-2.5 rounded-xl"
                >
                  <option>Patrol & Field Ops</option>
                  <option>Homicide Division</option>
                  <option>Cyber & Financial Crimes</option>
                  <option>Major Narcotics Unit</option>
                  <option>Robbery & Burglary</option>
                  <option>Special Investigations</option>
                  <option>Internal Affairs Division</option>
                  <option>Traffic Enforcement</option>
                  <option>Forensic & Evidence Unit</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">Contact Phone</label>
                <input
                  type="text"
                  name="contact"
                  value={formData.contact || ''}
                  onChange={handleChange}
                  className="w-full bg-slate-800/80 border border-slate-700/60 focus:border-brand-500 text-slate-100 px-3.5 py-2.5 rounded-xl font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">Official Email</label>
                <input
                  type="email"
                  name="email"
                  value={formData.email || ''}
                  onChange={handleChange}
                  className="w-full bg-slate-800/80 border border-slate-700/60 focus:border-brand-500 text-slate-100 px-3.5 py-2.5 rounded-xl font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">Duty Status</label>
                <select
                  name="status"
                  value={formData.status || 'Active'}
                  onChange={handleChange}
                  className="w-full bg-slate-800/80 border border-slate-700/60 focus:border-brand-500 text-slate-100 px-3.5 py-2.5 rounded-xl"
                >
                  <option>Active</option>
                  <option>On Leave</option>
                  <option>Under Investigation</option>
                  <option>Suspended</option>
                  <option>Retired</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">Assigned Shift</label>
                <select
                  name="shift"
                  value={formData.shift || 'Day'}
                  onChange={handleChange}
                  className="w-full bg-slate-800/80 border border-slate-700/60 focus:border-brand-500 text-slate-100 px-3.5 py-2.5 rounded-xl"
                >
                  <option>Day</option>
                  <option>Evening</option>
                  <option>Night</option>
                  <option>Rotating</option>
                </select>
              </div>
            </div>
          )}

          {/* CASES FIELDS */}
          {entityType === 'cases' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">Case Number *</label>
                <input
                  type="text"
                  name="case_number"
                  required
                  value={formData.case_number || ''}
                  onChange={handleChange}
                  className="w-full bg-slate-800/80 border border-slate-700/60 focus:border-brand-500 text-slate-100 px-3.5 py-2.5 rounded-xl font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">Crime Type *</label>
                <select
                  name="type"
                  value={formData.type || 'Robbery'}
                  onChange={handleChange}
                  className="w-full bg-slate-800/80 border border-slate-700/60 focus:border-brand-500 text-slate-100 px-3.5 py-2.5 rounded-xl"
                >
                  <option>Homicide</option>
                  <option>Robbery</option>
                  <option>Cybercrime</option>
                  <option>Narcotics</option>
                  <option>Assault</option>
                  <option>Internal Misconduct</option>
                  <option>Fraud & Embezzlement</option>
                  <option>Burglary</option>
                </select>
              </div>

              <div className="md:col-span-2">
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">Case Title *</label>
                <input
                  type="text"
                  name="title"
                  required
                  placeholder="e.g. Westside Bank Heist"
                  value={formData.title || ''}
                  onChange={handleChange}
                  className="w-full bg-slate-800/80 border border-slate-700/60 focus:border-brand-500 text-slate-100 px-3.5 py-2.5 rounded-xl"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">Incident Location *</label>
                <input
                  type="text"
                  name="location"
                  required
                  placeholder="e.g. 504 Main St, Downtown"
                  value={formData.location || ''}
                  onChange={handleChange}
                  className="w-full bg-slate-800/80 border border-slate-700/60 focus:border-brand-500 text-slate-100 px-3.5 py-2.5 rounded-xl"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">Incident Date/Time</label>
                <input
                  type="datetime-local"
                  name="incident_date"
                  value={formData.incident_date || ''}
                  onChange={handleChange}
                  className="w-full bg-slate-800/80 border border-slate-700/60 focus:border-brand-500 text-slate-100 px-3.5 py-2.5 rounded-xl font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">Priority Level</label>
                <select
                  name="priority"
                  value={formData.priority || 'Medium'}
                  onChange={handleChange}
                  className="w-full bg-slate-800/80 border border-slate-700/60 focus:border-brand-500 text-slate-100 px-3.5 py-2.5 rounded-xl"
                >
                  <option>Low</option>
                  <option>Medium</option>
                  <option>High</option>
                  <option>Critical</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">Investigation Status</label>
                <select
                  name="status"
                  value={formData.status || 'Open'}
                  onChange={handleChange}
                  className="w-full bg-slate-800/80 border border-slate-700/60 focus:border-brand-500 text-slate-100 px-3.5 py-2.5 rounded-xl"
                >
                  <option>Open</option>
                  <option>Under Investigation</option>
                  <option>Pending Review</option>
                  <option>Closed - Solved</option>
                  <option>Closed - Unsolved</option>
                </select>
              </div>

              <div className="md:col-span-2">
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">Assigned Lead Investigator (FK)</label>
                <select
                  name="assigned_officer_id"
                  value={formData.assigned_officer_id || ''}
                  onChange={handleChange}
                  className="w-full bg-slate-800/80 border border-slate-700/60 focus:border-brand-500 text-slate-100 px-3.5 py-2.5 rounded-xl"
                >
                  <option value="">-- Unassigned --</option>
                  {officersList.map((o) => (
                    <option key={o.officer_id} value={o.officer_id}>
                      {o.rank} {o.name} ({o.badge_number})
                    </option>
                  ))}
                </select>
              </div>

              <div className="md:col-span-2">
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">Description & Incident Narrative</label>
                <textarea
                  rows="3"
                  name="description"
                  placeholder="Summary of incident..."
                  value={formData.description || ''}
                  onChange={handleChange}
                  className="w-full bg-slate-800/80 border border-slate-700/60 focus:border-brand-500 text-slate-100 p-3 rounded-xl"
                />
              </div>
            </div>
          )}

          {/* PERSONS FIELDS */}
          {entityType === 'persons' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">Full Name *</label>
                <input
                  type="text"
                  name="name"
                  required
                  placeholder="e.g. John Doe"
                  value={formData.name || ''}
                  onChange={handleChange}
                  className="w-full bg-slate-800/80 border border-slate-700/60 focus:border-brand-500 text-slate-100 px-3.5 py-2.5 rounded-xl"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">Role / Status *</label>
                <select
                  name="role"
                  value={formData.role || 'Suspect'}
                  onChange={handleChange}
                  className="w-full bg-slate-800/80 border border-slate-700/60 focus:border-brand-500 text-slate-100 px-3.5 py-2.5 rounded-xl"
                >
                  <option>Suspect</option>
                  <option>Victim</option>
                  <option>Witness</option>
                  <option>Person of Interest</option>
                  <option>Informant</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">National ID</label>
                <input
                  type="text"
                  name="national_id"
                  value={formData.national_id || ''}
                  onChange={handleChange}
                  className="w-full bg-slate-800/80 border border-slate-700/60 focus:border-brand-500 text-slate-100 px-3.5 py-2.5 rounded-xl font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">Contact Phone</label>
                <input
                  type="text"
                  name="contact"
                  value={formData.contact || ''}
                  onChange={handleChange}
                  className="w-full bg-slate-800/80 border border-slate-700/60 focus:border-brand-500 text-slate-100 px-3.5 py-2.5 rounded-xl font-mono"
                />
              </div>

              <div className="md:col-span-2">
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">Linked Case (FK) *</label>
                <select
                  name="linked_case_id"
                  required
                  value={formData.linked_case_id || ''}
                  onChange={handleChange}
                  className="w-full bg-slate-800/80 border border-slate-700/60 focus:border-brand-500 text-slate-100 px-3.5 py-2.5 rounded-xl"
                >
                  {casesList.map((c) => (
                    <option key={c.case_id} value={c.case_id}>
                      {c.case_number} - {c.title}
                    </option>
                  ))}
                </select>
              </div>

              <div className="md:col-span-2">
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">Address / Location</label>
                <input
                  type="text"
                  name="address"
                  value={formData.address || ''}
                  onChange={handleChange}
                  className="w-full bg-slate-800/80 border border-slate-700/60 focus:border-brand-500 text-slate-100 px-3.5 py-2.5 rounded-xl"
                />
              </div>
            </div>
          )}

          {/* ARRESTS FIELDS */}
          {entityType === 'arrests' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">Accused Suspect (FK) *</label>
                <select
                  name="person_id"
                  required
                  value={formData.person_id || ''}
                  onChange={handleChange}
                  className="w-full bg-slate-800/80 border border-slate-700/60 focus:border-brand-500 text-slate-100 px-3.5 py-2.5 rounded-xl"
                >
                  {personsList.map((p) => (
                    <option key={p.person_id} value={p.person_id}>
                      {p.name} ({p.role})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">Originating Case (FK) *</label>
                <select
                  name="case_id"
                  required
                  value={formData.case_id || ''}
                  onChange={handleChange}
                  className="w-full bg-slate-800/80 border border-slate-700/60 focus:border-brand-500 text-slate-100 px-3.5 py-2.5 rounded-xl"
                >
                  {casesList.map((c) => (
                    <option key={c.case_id} value={c.case_id}>
                      {c.case_number} - {c.title}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">Arresting Officer (FK) *</label>
                <select
                  name="officer_id"
                  required
                  value={formData.officer_id || ''}
                  onChange={handleChange}
                  className="w-full bg-slate-800/80 border border-slate-700/60 focus:border-brand-500 text-slate-100 px-3.5 py-2.5 rounded-xl"
                >
                  {officersList.map((o) => (
                    <option key={o.officer_id} value={o.officer_id}>
                      {o.rank} {o.name} ({o.badge_number})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">Booking Status</label>
                <select
                  name="booking_status"
                  value={formData.booking_status || 'In Custody'}
                  onChange={handleChange}
                  className="w-full bg-slate-800/80 border border-slate-700/60 focus:border-brand-500 text-slate-100 px-3.5 py-2.5 rounded-xl"
                >
                  <option>In Custody</option>
                  <option>Released on Bail</option>
                  <option>Awaiting Trial</option>
                  <option>Transferred to Prison</option>
                  <option>Charges Dropped</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">Bail Amount ($)</label>
                <input
                  type="number"
                  step="1000"
                  name="bail_amount"
                  value={formData.bail_amount || 0}
                  onChange={handleChange}
                  className="w-full bg-slate-800/80 border border-slate-700/60 focus:border-brand-500 text-slate-100 px-3.5 py-2.5 rounded-xl font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">Arrest Date</label>
                <input
                  type="datetime-local"
                  name="arrest_date"
                  value={formData.arrest_date || ''}
                  onChange={handleChange}
                  className="w-full bg-slate-800/80 border border-slate-700/60 focus:border-brand-500 text-slate-100 px-3.5 py-2.5 rounded-xl font-mono"
                />
              </div>

              <div className="md:col-span-2">
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">Statutory Charges Filed *</label>
                <textarea
                  rows="2"
                  name="charges"
                  required
                  value={formData.charges || ''}
                  onChange={handleChange}
                  className="w-full bg-slate-800/80 border border-slate-700/60 focus:border-brand-500 text-slate-100 p-3 rounded-xl font-mono"
                />
              </div>
            </div>
          )}

          {/* EVIDENCE FIELDS */}
          {entityType === 'evidence' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="md:col-span-2">
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">Associated Case (FK) *</label>
                <select
                  name="case_id"
                  required
                  value={formData.case_id || ''}
                  onChange={handleChange}
                  className="w-full bg-slate-800/80 border border-slate-700/60 focus:border-brand-500 text-slate-100 px-3.5 py-2.5 rounded-xl"
                >
                  {casesList.map((c) => (
                    <option key={c.case_id} value={c.case_id}>
                      {c.case_number} - {c.title}
                    </option>
                  ))}
                </select>
              </div>

              <div className="md:col-span-2">
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">Evidence Item Name *</label>
                <input
                  type="text"
                  name="item_name"
                  required
                  placeholder="e.g. Glock 19 Handgun"
                  value={formData.item_name || ''}
                  onChange={handleChange}
                  className="w-full bg-slate-800/80 border border-slate-700/60 focus:border-brand-500 text-slate-100 px-3.5 py-2.5 rounded-xl"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">Category</label>
                <select
                  name="evidence_type"
                  value={formData.evidence_type || 'Physical'}
                  onChange={handleChange}
                  className="w-full bg-slate-800/80 border border-slate-700/60 focus:border-brand-500 text-slate-100 px-3.5 py-2.5 rounded-xl"
                >
                  <option>Physical</option>
                  <option>Digital</option>
                  <option>Biological/DNA</option>
                  <option>Ballistics</option>
                  <option>Documentary</option>
                  <option>Narcotics</option>
                  <option>Other</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">Vault Storage Locker *</label>
                <input
                  type="text"
                  name="storage_location"
                  required
                  placeholder="e.g. Vault A - Locker 102"
                  value={formData.storage_location || ''}
                  onChange={handleChange}
                  className="w-full bg-slate-800/80 border border-slate-700/60 focus:border-brand-500 text-slate-100 px-3.5 py-2.5 rounded-xl font-mono"
                />
              </div>

              <div className="md:col-span-2">
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">Chain of Custody</label>
                <input
                  type="text"
                  name="chain_of_custody"
                  value={formData.chain_of_custody || ''}
                  onChange={handleChange}
                  className="w-full bg-slate-800/80 border border-slate-700/60 focus:border-brand-500 text-slate-100 px-3.5 py-2.5 rounded-xl font-mono"
                />
              </div>
            </div>
          )}

          {/* COMPLAINTS FIELDS */}
          {entityType === 'complaints' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">IA Case # *</label>
                <input
                  type="text"
                  name="complaint_number"
                  required
                  value={formData.complaint_number || ''}
                  onChange={handleChange}
                  className="w-full bg-slate-800/80 border border-slate-700/60 focus:border-brand-500 text-slate-100 px-3.5 py-2.5 rounded-xl font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">Subject Officer (FK) *</label>
                <select
                  name="officer_id"
                  required
                  value={formData.officer_id || ''}
                  onChange={handleChange}
                  className="w-full bg-slate-800/80 border border-slate-700/60 focus:border-brand-500 text-slate-100 px-3.5 py-2.5 rounded-xl"
                >
                  {officersList.map((o) => (
                    <option key={o.officer_id} value={o.officer_id}>
                      {o.rank} {o.name} ({o.badge_number})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">Complainant Name *</label>
                <input
                  type="text"
                  name="complainant_name"
                  required
                  value={formData.complainant_name || ''}
                  onChange={handleChange}
                  className="w-full bg-slate-800/80 border border-slate-700/60 focus:border-brand-500 text-slate-100 px-3.5 py-2.5 rounded-xl"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">Allegation Type</label>
                <select
                  name="allegation_type"
                  value={formData.allegation_type || 'Misconduct'}
                  onChange={handleChange}
                  className="w-full bg-slate-800/80 border border-slate-700/60 focus:border-brand-500 text-slate-100 px-3.5 py-2.5 rounded-xl"
                >
                  <option>Excessive Force</option>
                  <option>Misconduct</option>
                  <option>Corruption / Bribery</option>
                  <option>Dereliction of Duty</option>
                  <option>Harassment</option>
                  <option>Procedural Violation</option>
                  <option>Unlawful Search</option>
                </select>
              </div>

              <div className="md:col-span-2">
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">Grievance Narrative *</label>
                <textarea
                  rows="3"
                  name="description"
                  required
                  value={formData.description || ''}
                  onChange={handleChange}
                  className="w-full bg-slate-800/80 border border-slate-700/60 focus:border-brand-500 text-slate-100 p-3 rounded-xl"
                />
              </div>
            </div>
          )}

          {/* Footer Actions */}
          <div className="pt-5 border-t border-slate-800 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="flex items-center gap-2 px-5 py-2 rounded-xl bg-gradient-to-r from-brand-400 via-brand-500 to-amber-500 hover:from-brand-300 hover:to-brand-400 text-slate-950 font-bold text-xs shadow-md shadow-black/20 hover:shadow-black/30 border border-brand-300/40 transition-all active:scale-95"
            >
              <Check className="w-4 h-4 stroke-[3]" />
              <span>{loading ? 'Saving...' : 'Save Record'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
