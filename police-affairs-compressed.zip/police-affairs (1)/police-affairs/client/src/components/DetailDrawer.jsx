import React from 'react';
import { X, ExternalLink, Shield, FolderOpen, User, Lock, Archive, AlertCircle, Calendar, MapPin, Phone, Mail } from 'lucide-react';

export function DetailDrawer({ isOpen, onClose, item, type, onEdit, onDelete }) {
  if (!isOpen || !item) return null;

  return (
    <div className="fixed inset-0 z-40 overflow-hidden select-none animate-in fade-in">
      {/* Backdrop */}
      <div 
        onClick={onClose}
        className="absolute inset-0 bg-slate-950/60 backdrop-blur-sm transition-opacity"
      />

      {/* Slide-over panel */}
      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-slate-900 border-l border-slate-800 shadow-2xl flex flex-col justify-between">
          <div>
            {/* Header */}
            <div className="px-6 py-5 border-b border-slate-800 flex items-center justify-between">
              <div>
                <span className="text-[10px] font-bold text-brand-400 uppercase tracking-wider">{type} Details</span>
                <h3 className="text-base font-bold text-white truncate mt-0.5">
                  {item.title || item.name || item.case_number || item.item_name || item.complaint_number}
                </h3>
              </div>
              <button
                onClick={onClose}
                className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Content Body */}
            <div className="p-6 space-y-5 overflow-y-auto max-h-[calc(100vh-140px)] text-xs">
              {/* Primary Key / Code */}
              {(item.case_number || item.badge_number || item.complaint_number || item.national_id) && (
                <div className="p-3 rounded-xl bg-slate-850 border border-slate-800 flex items-center justify-between">
                  <span className="text-slate-400 font-medium">Record Identifier</span>
                  <span className="font-mono font-bold text-brand-300">
                    {item.case_number || item.badge_number || item.complaint_number || item.national_id}
                  </span>
                </div>
              )}

              {/* Status / Priority Badges */}
              <div className="flex items-center gap-2">
                {item.status && (
                  <span className="px-3 py-1 rounded-full bg-slate-800 border border-slate-700 text-slate-200 font-semibold">
                    Status: {item.status}
                  </span>
                )}
                {item.priority && (
                  <span className={`px-3 py-1 rounded-full border font-bold ${
                    item.priority === 'Critical' ? 'text-rose-400 bg-rose-500/10 border-rose-500/20' :
                    item.priority === 'High' ? 'text-amber-400 bg-amber-500/10 border-amber-500/20' :
                    'text-sky-400 bg-sky-500/10 border-sky-500/20'
                  }`}>
                    {item.priority} Priority
                  </span>
                )}
              </div>

              {/* Description / Notes */}
              {(item.description || item.notes || item.charges) && (
                <div>
                  <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block mb-1.5">
                    Case Narrative & Notes
                  </span>
                  <div className="p-3.5 rounded-xl bg-slate-850 border border-slate-800 text-slate-300 leading-relaxed">
                    {item.description || item.notes || item.charges}
                  </div>
                </div>
              )}

              {/* Metadata Fields */}
              <div>
                <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block mb-2">
                  Relational Attributes
                </span>
                <div className="divide-y divide-slate-800/80 rounded-xl bg-slate-850 border border-slate-800 px-3.5">
                  {Object.entries(item)
                    .filter(([key]) => !['description', 'notes', 'charges', 'investigator_notes', 'assignedCases', 'arrestsMade', 'complaints', 'persons', 'evidence', 'arrests'].includes(key))
                    .slice(0, 10)
                    .map(([key, val]) => (
                      <div key={key} className="py-2.5 flex items-center justify-between">
                        <span className="text-slate-400 capitalize">{key.replace(/_/g, ' ')}</span>
                        <span className="font-semibold text-slate-200 font-mono truncate max-w-[200px]">
                          {String(val !== null && val !== undefined ? val : '—')}
                        </span>
                      </div>
                    ))}
                </div>
              </div>
            </div>
          </div>

          {/* Footer Actions */}
          <div className="p-5 border-t border-slate-800 flex items-center justify-end gap-3 bg-slate-900">
            <button
              onClick={() => onEdit(item)}
              className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs transition-colors"
            >
              Edit Entry
            </button>
            <button
              onClick={() => {
                onDelete(item);
                onClose();
              }}
              className="px-4 py-2 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/20 font-semibold text-xs transition-colors"
            >
              Delete Record
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
