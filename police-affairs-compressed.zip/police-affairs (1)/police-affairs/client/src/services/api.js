const API_BASE = '/api';

export const api = {
  // Stats
  getStats: () => fetch(`${API_BASE}/stats`).then(res => res.json()),

  // Officers
  getOfficers: (params = {}) => {
    const query = new URLSearchParams(params).toString();
    return fetch(`${API_BASE}/officers${query ? `?${query}` : ''}`).then(res => res.json());
  },
  getOfficerById: (id) => fetch(`${API_BASE}/officers/${id}`).then(res => res.json()),
  createOfficer: (data) => fetch(`${API_BASE}/officers`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  }).then(res => res.json()),
  updateOfficer: (id, data) => fetch(`${API_BASE}/officers/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  }).then(res => res.json()),
  deleteOfficer: (id) => fetch(`${API_BASE}/officers/${id}`, { method: 'DELETE' }).then(res => res.json()),

  // Cases
  getCases: (params = {}) => {
    const query = new URLSearchParams(params).toString();
    return fetch(`${API_BASE}/cases${query ? `?${query}` : ''}`).then(res => res.json());
  },
  getCaseById: (id) => fetch(`${API_BASE}/cases/${id}`).then(res => res.json()),
  createCase: (data) => fetch(`${API_BASE}/cases`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  }).then(res => res.json()),
  updateCase: (id, data) => fetch(`${API_BASE}/cases/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  }).then(res => res.json()),
  deleteCase: (id) => fetch(`${API_BASE}/cases/${id}`, { method: 'DELETE' }).then(res => res.json()),

  // Persons
  getPersons: (params = {}) => {
    const query = new URLSearchParams(params).toString();
    return fetch(`${API_BASE}/persons${query ? `?${query}` : ''}`).then(res => res.json());
  },
  createPerson: (data) => fetch(`${API_BASE}/persons`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  }).then(res => res.json()),
  updatePerson: (id, data) => fetch(`${API_BASE}/persons/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  }).then(res => res.json()),
  deletePerson: (id) => fetch(`${API_BASE}/persons/${id}`, { method: 'DELETE' }).then(res => res.json()),

  // Arrests
  getArrests: (params = {}) => {
    const query = new URLSearchParams(params).toString();
    return fetch(`${API_BASE}/arrests${query ? `?${query}` : ''}`).then(res => res.json());
  },
  createArrest: (data) => fetch(`${API_BASE}/arrests`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  }).then(res => res.json()),
  updateArrest: (id, data) => fetch(`${API_BASE}/arrests/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  }).then(res => res.json()),
  deleteArrest: (id) => fetch(`${API_BASE}/arrests/${id}`, { method: 'DELETE' }).then(res => res.json()),

  // Evidence
  getEvidence: (params = {}) => {
    const query = new URLSearchParams(params).toString();
    return fetch(`${API_BASE}/evidence${query ? `?${query}` : ''}`).then(res => res.json());
  },
  createEvidence: (data) => fetch(`${API_BASE}/evidence`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  }).then(res => res.json()),
  updateEvidence: (id, data) => fetch(`${API_BASE}/evidence/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  }).then(res => res.json()),
  deleteEvidence: (id) => fetch(`${API_BASE}/evidence/${id}`, { method: 'DELETE' }).then(res => res.json()),

  // Complaints (Internal Affairs)
  getComplaints: (params = {}) => {
    const query = new URLSearchParams(params).toString();
    return fetch(`${API_BASE}/complaints${query ? `?${query}` : ''}`).then(res => res.json());
  },
  createComplaint: (data) => fetch(`${API_BASE}/complaints`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  }).then(res => res.json()),
  updateComplaint: (id, data) => fetch(`${API_BASE}/complaints/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  }).then(res => res.json()),
  deleteComplaint: (id) => fetch(`${API_BASE}/complaints/${id}`, { method: 'DELETE' }).then(res => res.json()),

  // Export MySQL
  exportMySQL: () => {
    window.open(`${API_BASE}/export-mysql`, '_blank');
  }
};
