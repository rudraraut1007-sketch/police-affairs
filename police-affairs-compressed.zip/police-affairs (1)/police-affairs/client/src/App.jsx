import React, { useState, useEffect } from 'react';
import { Sidebar } from './components/Sidebar';
import { TopNav } from './components/TopNav';
import { DashboardView } from './components/DashboardView';
import { OfficersView } from './components/OfficersView';
import { CasesView } from './components/CasesView';
import { PersonsView } from './components/PersonsView';
import { ArrestsView } from './components/ArrestsView';
import { EvidenceView } from './components/EvidenceView';
import { ComplaintsView } from './components/ComplaintsView';
import { ModalForm } from './components/ModalForm';
import { DetailDrawer } from './components/DetailDrawer';
import { api } from './services/api';

export default function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [stats, setStats] = useState(null);
  const [officers, setOfficers] = useState([]);
  const [cases, setCases] = useState([]);
  const [persons, setPersons] = useState([]);
  const [arrests, setArrests] = useState([]);
  const [evidence, setEvidence] = useState([]);
  const [complaints, setComplaints] = useState([]);
  
  const [selectedItem, setSelectedItem] = useState(null);
  const [selectedType, setSelectedType] = useState('Case');
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);

  const [globalSearch, setGlobalSearch] = useState('');
  
  // Modal state
  const [modalOpen, setModalOpen] = useState(false);
  const [modalEntity, setModalEntity] = useState('cases');
  const [modalData, setModalData] = useState(null);

  // Load all initial data
  const loadAllData = async () => {
    try {
      const [statsData, officersData, casesData, personsData, arrestsData, evidenceData, complaintsData] = await Promise.all([
        api.getStats(),
        api.getOfficers(),
        api.getCases(),
        api.getPersons(),
        api.getArrests(),
        api.getEvidence(),
        api.getComplaints()
      ]);

      setStats(statsData);
      setOfficers(officersData);
      setCases(casesData);
      setPersons(personsData);
      setArrests(arrestsData);
      setEvidence(evidenceData);
      setComplaints(complaintsData);
    } catch (err) {
      console.error('Error fetching data from API:', err);
    }
  };

  useEffect(() => {
    loadAllData();
  }, []);

  // Open inspection drawer
  const handleInspect = (item, type) => {
    setSelectedItem(item);
    setSelectedType(type);
    setIsDrawerOpen(true);
  };

  // CRUD Handlers
  const handleModalSubmit = async (formData) => {
    if (modalData) {
      // Edit
      if (modalEntity === 'officers') await api.updateOfficer(modalData.officer_id, formData);
      else if (modalEntity === 'cases') await api.updateCase(modalData.case_id, formData);
      else if (modalEntity === 'persons') await api.updatePerson(modalData.person_id, formData);
      else if (modalEntity === 'arrests') await api.updateArrest(modalData.arrest_id, formData);
      else if (modalEntity === 'evidence') await api.updateEvidence(modalData.evidence_id, formData);
      else if (modalEntity === 'complaints') await api.updateComplaint(modalData.complaint_id, formData);
    } else {
      // Create
      if (modalEntity === 'officers') await api.createOfficer(formData);
      else if (modalEntity === 'cases') await api.createCase(formData);
      else if (modalEntity === 'persons') await api.createPerson(formData);
      else if (modalEntity === 'arrests') await api.createArrest(formData);
      else if (modalEntity === 'evidence') await api.createEvidence(formData);
      else if (modalEntity === 'complaints') await api.createComplaint(formData);
    }
    await loadAllData();
  };

  const handleDelete = async (type, id) => {
    if (type === 'officers') await api.deleteOfficer(id);
    else if (type === 'cases') await api.deleteCase(id);
    else if (type === 'persons') await api.deletePerson(id);
    else if (type === 'arrests') await api.deleteArrest(id);
    else if (type === 'evidence') await api.deleteEvidence(id);
    else if (type === 'complaints') await api.deleteComplaint(id);
    await loadAllData();
  };

  const openCreateModal = (entity) => {
    setModalEntity(entity || (activeTab === 'dashboard' ? 'cases' : activeTab));
    setModalData(null);
    setModalOpen(true);
  };

  const openEditModal = (entity, data) => {
    setModalEntity(entity);
    setModalData(data);
    setModalOpen(true);
  };

  const counts = {
    cases: cases.length,
    officers: officers.length,
    persons: persons.length,
    arrests: arrests.length,
    evidence: evidence.length,
    complaints: complaints.length
  };

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-slate-950 text-slate-100 select-none">
      {/* 1. Modern Sidebar Navigation */}
      <Sidebar activeTab={activeTab} onSelectTab={setActiveTab} counts={counts} />

      {/* 2. Central Workspace */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top Header */}
        <TopNav
          activeTab={activeTab}
          onOpenNewModal={() => openCreateModal(activeTab === 'dashboard' ? 'cases' : activeTab)}
          onRefresh={loadAllData}
          globalSearch={globalSearch}
          setGlobalSearch={setGlobalSearch}
        />

        {/* Main Workspace Content Area */}
        <main className="flex-1 overflow-y-auto p-6 bg-slate-950">
          {activeTab === 'dashboard' && (
            <DashboardView
              stats={stats}
              onSelectCase={(c) => handleInspect(c, 'Case')}
              onSelectTab={setActiveTab}
              onOpenNewCase={() => openCreateModal('cases')}
            />
          )}

          {activeTab === 'cases' && (
            <CasesView
              cases={cases}
              onSelectCase={(c) => handleInspect(c, 'Case')}
              onEditCase={(c) => openEditModal('cases', c)}
              onDeleteCase={(id) => handleDelete('cases', id)}
              onAddNewCase={() => openCreateModal('cases')}
            />
          )}

          {activeTab === 'officers' && (
            <OfficersView
              officers={officers}
              onSelectOfficer={(o) => handleInspect(o, 'Officer')}
              onEditOfficer={(o) => openEditModal('officers', o)}
              onDeleteOfficer={(id) => handleDelete('officers', id)}
              onAddNewOfficer={() => openCreateModal('officers')}
            />
          )}

          {activeTab === 'persons' && (
            <PersonsView
              persons={persons}
              onSelectPerson={(p) => handleInspect(p, 'Person')}
              onEditPerson={(p) => openEditModal('persons', p)}
              onDeletePerson={(id) => handleDelete('persons', id)}
              onAddNewPerson={() => openCreateModal('persons')}
            />
          )}

          {activeTab === 'arrests' && (
            <ArrestsView
              arrests={arrests}
              onSelectArrest={(a) => handleInspect(a, 'Arrest')}
              onEditArrest={(a) => openEditModal('arrests', a)}
              onDeleteArrest={(id) => handleDelete('arrests', id)}
              onAddNewArrest={() => openCreateModal('arrests')}
            />
          )}

          {activeTab === 'evidence' && (
            <EvidenceView
              evidence={evidence}
              onSelectEvidence={(e) => handleInspect(e, 'Evidence')}
              onEditEvidence={(e) => openEditModal('evidence', e)}
              onDeleteEvidence={(id) => handleDelete('evidence', id)}
              onAddNewEvidence={() => openCreateModal('evidence')}
            />
          )}

          {activeTab === 'complaints' && (
            <ComplaintsView
              complaints={complaints}
              onSelectComplaint={(cp) => handleInspect(cp, 'Complaint')}
              onEditComplaint={(cp) => openEditModal('complaints', cp)}
              onDeleteComplaint={(id) => handleDelete('complaints', id)}
              onAddNewComplaint={() => openCreateModal('complaints')}
            />
          )}
        </main>
      </div>

      {/* Slide-over Detail Drawer */}
      <DetailDrawer
        isOpen={isDrawerOpen}
        onClose={() => setIsDrawerOpen(false)}
        item={selectedItem}
        type={selectedType}
        onEdit={(item) => {
          setIsDrawerOpen(false);
          openEditModal(selectedType.toLowerCase() + 's', item);
        }}
        onDelete={(item) => {
          const typeKey = selectedType.toLowerCase() + 's';
          const idKey = selectedType.toLowerCase() + '_id';
          handleDelete(typeKey, item[idKey]);
        }}
      />

      {/* Universal Modal */}
      <ModalForm
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        entityType={modalEntity}
        initialData={modalData}
        onSubmit={handleModalSubmit}
        officersList={officers}
        casesList={cases}
        personsList={persons}
      />
    </div>
  );
}
